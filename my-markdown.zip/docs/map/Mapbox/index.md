# Mapbox

在创建地图例子时若图层无法显示 可前往[官网](https://docs.mapbox.com/mapbox-gl-js/guides/install/#transpiling)查看

```js
import mapboxgl from '!mapbox-gl'; // 若Babel错误可尝试这样。使mapbox-gl不被转换器转换
```

# 分屏展示 Demo

<code src='./mapboxSync'></code>
