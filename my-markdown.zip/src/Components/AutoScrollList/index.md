---
nav:
  path: /components
group:
  path: /AutoScrollList
---

# AutoScrollList

用于处理大批量数据生成的列表

根据每个元素的高度和展示数量确定内容盒子高度

demo:
<code src='./index.tsx'></code>
