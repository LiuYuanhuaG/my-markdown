---
nav:
  title: Components
  path: /components
group:
  path: /EditTableHeader
---

# EditTableHeader

Demo:

<code src='./index.tsx'></code>
