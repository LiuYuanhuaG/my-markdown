// @ts-nocheck
import React from 'react';
import { dynamic } from 'dumi';
import rawCode1 from '!!dumi-raw-code-loader!F:/LYH_work/mycode/my-markdown/src/Components/EditTableHeader/index.tsx?dumi-raw-code';
import rawCode2 from '!!dumi-raw-code-loader!F:/LYH_work/mycode/my-markdown/src/Components/Test/index.tsx?dumi-raw-code';
import rawCode3 from '!!dumi-raw-code-loader!F:/LYH_work/mycode/my-markdown/src/Components/Test/demo.tsx?dumi-raw-code';
import rawCode4 from '!!dumi-raw-code-loader!F:/LYH_work/mycode/my-markdown/src/Components/Test/demo.less?dumi-raw-code';
import rawCode5 from '!!dumi-raw-code-loader!F:/LYH_work/mycode/my-markdown/src/Components/Test/FileListItem.tsx?dumi-raw-code';
import rawCode6 from '!!dumi-raw-code-loader!F:/LYH_work/mycode/my-markdown/src/Components/Test/FileListItem.less?dumi-raw-code';
import rawCode7 from '!!dumi-raw-code-loader!F:/LYH_work/mycode/my-markdown/docs/map/Leaflet/demo.tsx?dumi-raw-code';
import rawCode8 from '!!dumi-raw-code-loader!F:/LYH_work/mycode/my-markdown/docs/map/Mapbox/mapboxSync.tsx?dumi-raw-code';
import rawCode9 from '!!dumi-raw-code-loader!F:/LYH_work/mycode/my-markdown/src/Components/AutoScrollList/index.tsx?dumi-raw-code';

export default {
  'components-edittableheader': {
    component: dynamic({
      loader: async () => (await import(/* webpackChunkName: "demos_redaeHelbaTtidE" */'F:/LYH_work/mycode/my-markdown/src/Components/EditTableHeader/index.tsx')).default,
      loading: () => null,
    }),
    previewerProps: {"sources":{"_":{"tsx":rawCode1}},"dependencies":{"react":{"version":">=16.9.0"},"antd":{"version":"4.24.2","css":"antd/dist/antd.css"},"react-dom":{"version":">=16.9.0"}},"componentName":"EditTableHeader","identifier":"components-edittableheader"},
  },
  'EditTableHeader-1-demo': {
    component: dynamic({
  loader: async function () {
    var _interopRequireWildcard = require("F:/LYH_work/mycode/my-markdown/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireWildcard.js")["default"];

    var _interopRequireDefault = require("F:/LYH_work/mycode/my-markdown/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireDefault.js")["default"];

    var _extends2 = _interopRequireDefault(await import("F:/LYH_work/mycode/my-markdown/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/extends.js"));

    var _objectSpread2 = _interopRequireDefault(await import("F:/LYH_work/mycode/my-markdown/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/objectSpread2.js"));

    var _slicedToArray2 = _interopRequireDefault(await import("F:/LYH_work/mycode/my-markdown/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/slicedToArray.js"));

    var _icons = await import("@ant-design/icons");

    var _antd = await import("antd");

    var _react = _interopRequireWildcard(await import("react"));

    var columns = [{
      title: 'Name',
      dataIndex: 'name'
    }, {
      title: 'Age',
      dataIndex: 'age',
      sorter: function sorter(a, b) {
        return a.age - b.age;
      }
    }, {
      title: 'Address',
      dataIndex: 'address',
      filters: [{
        text: 'London',
        value: 'London'
      }, {
        text: 'New York',
        value: 'New York'
      }],
      onFilter: function onFilter(value, record) {
        return record.address.indexOf(value) === 0;
      }
    }, {
      title: 'Action',
      key: 'action',
      sorter: true,
      render: function render() {
        return /*#__PURE__*/_react["default"].createElement(_antd.Space, {
          size: "middle"
        }, /*#__PURE__*/_react["default"].createElement("a", null, "Delete"), /*#__PURE__*/_react["default"].createElement("a", null, /*#__PURE__*/_react["default"].createElement(_antd.Space, null, "More actions", /*#__PURE__*/_react["default"].createElement(_icons.DownOutlined, null))));
      }
    }];
    var data = [];

    for (var i = 1; i <= 10; i++) {
      data.push({
        key: i,
        name: 'John Brown',
        age: Number("".concat(i, "2")),
        address: "New York No. ".concat(i, " Lake Park"),
        description: "My name is John Brown, I am ".concat(i, "2 years old, living in New York No. ").concat(i, " Lake Park.")
      });
    }

    var defaultExpandable = {
      expandedRowRender: function expandedRowRender(record) {
        return /*#__PURE__*/_react["default"].createElement("p", null, record.description);
      }
    };

    var defaultTitle = function defaultTitle() {
      return 'Here is title';
    };

    var defaultFooter = function defaultFooter() {
      return 'Here is footer';
    };

    var App = function App() {
      var _useState = (0, _react.useState)(false),
          _useState2 = (0, _slicedToArray2["default"])(_useState, 2),
          bordered = _useState2[0],
          setBordered = _useState2[1];

      var _useState3 = (0, _react.useState)(false),
          _useState4 = (0, _slicedToArray2["default"])(_useState3, 2),
          loading = _useState4[0],
          setLoading = _useState4[1];

      var _useState5 = (0, _react.useState)('large'),
          _useState6 = (0, _slicedToArray2["default"])(_useState5, 2),
          size = _useState6[0],
          setSize = _useState6[1];

      var _useState7 = (0, _react.useState)(defaultExpandable),
          _useState8 = (0, _slicedToArray2["default"])(_useState7, 2),
          expandable = _useState8[0],
          setExpandable = _useState8[1];

      var _useState9 = (0, _react.useState)(false),
          _useState10 = (0, _slicedToArray2["default"])(_useState9, 2),
          showTitle = _useState10[0],
          setShowTitle = _useState10[1];

      var _useState11 = (0, _react.useState)(true),
          _useState12 = (0, _slicedToArray2["default"])(_useState11, 2),
          showHeader = _useState12[0],
          setShowHeader = _useState12[1];

      var _useState13 = (0, _react.useState)(true),
          _useState14 = (0, _slicedToArray2["default"])(_useState13, 2),
          showfooter = _useState14[0],
          setShowFooter = _useState14[1];

      var _useState15 = (0, _react.useState)({}),
          _useState16 = (0, _slicedToArray2["default"])(_useState15, 2),
          rowSelection = _useState16[0],
          setRowSelection = _useState16[1];

      var _useState17 = (0, _react.useState)(true),
          _useState18 = (0, _slicedToArray2["default"])(_useState17, 2),
          hasData = _useState18[0],
          setHasData = _useState18[1];

      var _useState19 = (0, _react.useState)(undefined),
          _useState20 = (0, _slicedToArray2["default"])(_useState19, 2),
          tableLayout = _useState20[0],
          setTableLayout = _useState20[1];

      var _useState21 = (0, _react.useState)('none'),
          _useState22 = (0, _slicedToArray2["default"])(_useState21, 2),
          top = _useState22[0],
          setTop = _useState22[1];

      var _useState23 = (0, _react.useState)('bottomRight'),
          _useState24 = (0, _slicedToArray2["default"])(_useState23, 2),
          bottom = _useState24[0],
          setBottom = _useState24[1];

      var _useState25 = (0, _react.useState)(false),
          _useState26 = (0, _slicedToArray2["default"])(_useState25, 2),
          ellipsis = _useState26[0],
          setEllipsis = _useState26[1];

      var _useState27 = (0, _react.useState)(false),
          _useState28 = (0, _slicedToArray2["default"])(_useState27, 2),
          yScroll = _useState28[0],
          setYScroll = _useState28[1];

      var _useState29 = (0, _react.useState)(undefined),
          _useState30 = (0, _slicedToArray2["default"])(_useState29, 2),
          xScroll = _useState30[0],
          setXScroll = _useState30[1];

      var handleBorderChange = function handleBorderChange(enable) {
        setBordered(enable);
      };

      var handleLoadingChange = function handleLoadingChange(enable) {
        setLoading(enable);
      };

      var handleSizeChange = function handleSizeChange(e) {
        setSize(e.target.value);
      };

      var handleTableLayoutChange = function handleTableLayoutChange(e) {
        setTableLayout(e.target.value);
      };

      var handleExpandChange = function handleExpandChange(enable) {
        setExpandable(enable ? defaultExpandable : undefined);
      };

      var handleEllipsisChange = function handleEllipsisChange(enable) {
        setEllipsis(enable);
      };

      var handleTitleChange = function handleTitleChange(enable) {
        setShowTitle(enable);
      };

      var handleHeaderChange = function handleHeaderChange(enable) {
        setShowHeader(enable);
      };

      var handleFooterChange = function handleFooterChange(enable) {
        setShowFooter(enable);
      };

      var handleRowSelectionChange = function handleRowSelectionChange(enable) {
        setRowSelection(enable ? {} : undefined);
      };

      var handleYScrollChange = function handleYScrollChange(enable) {
        setYScroll(enable);
      };

      var handleXScrollChange = function handleXScrollChange(e) {
        setXScroll(e.target.value);
      };

      var handleDataChange = function handleDataChange(newHasData) {
        setHasData(newHasData);
      };

      var scroll = {};

      if (yScroll) {
        scroll.y = 240;
      }

      if (xScroll) {
        scroll.x = '100vw';
      }

      console.log(scroll, 'scroll');
      var tableColumns = columns.map(function (item) {
        return (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, item), {}, {
          ellipsis: ellipsis
        });
      });

      if (xScroll === 'fixed') {
        tableColumns[0].fixed = true;
        tableColumns[tableColumns.length - 1].fixed = 'right';
      }

      var tableProps = {
        bordered: bordered,
        loading: loading,
        size: size,
        expandable: expandable,
        title: showTitle ? defaultTitle : undefined,
        showHeader: showHeader,
        footer: showfooter ? defaultFooter : undefined,
        rowSelection: rowSelection,
        scroll: scroll,
        tableLayout: tableLayout
      };
      return /*#__PURE__*/_react["default"].createElement(_react["default"].Fragment, null, /*#__PURE__*/_react["default"].createElement(_antd.Form, {
        layout: "inline",
        className: "components-table-demo-control-bar",
        style: {
          marginBottom: 16
        }
      }, /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Bordered"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Switch, {
        checked: bordered,
        onChange: handleBorderChange
      })), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "loading"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Switch, {
        checked: loading,
        onChange: handleLoadingChange
      })), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Title"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Switch, {
        checked: showTitle,
        onChange: handleTitleChange
      })), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Column Header"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Switch, {
        checked: showHeader,
        onChange: handleHeaderChange
      })), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Footer"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Switch, {
        checked: showfooter,
        onChange: handleFooterChange
      })), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Expandable"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Switch, {
        checked: !!expandable,
        onChange: handleExpandChange
      })), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Checkbox"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Switch, {
        checked: !!rowSelection,
        onChange: handleRowSelectionChange
      })), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Fixed Header"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Switch, {
        checked: !!yScroll,
        onChange: handleYScrollChange
      })), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Has Data"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Switch, {
        checked: !!hasData,
        onChange: handleDataChange
      })), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Ellipsis"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Switch, {
        checked: !!ellipsis,
        onChange: handleEllipsisChange
      })), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Size"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Radio.Group, {
        value: size,
        onChange: handleSizeChange
      }, /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "large"
      }, "Large"), /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "middle"
      }, "Middle"), /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "small"
      }, "Small"))), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Table Scroll"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Radio.Group, {
        value: xScroll,
        onChange: handleXScrollChange
      }, /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: undefined
      }, "Unset"), /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "scroll"
      }, "Scroll"), /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "fixed"
      }, "Fixed Columns"))), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Table Layout"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Radio.Group, {
        value: tableLayout,
        onChange: handleTableLayoutChange
      }, /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: undefined
      }, "Unset"), /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "fixed"
      }, "Fixed"))), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Pagination Top"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Radio.Group, {
        value: top,
        onChange: function onChange(e) {
          setTop(e.target.value);
        }
      }, /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "topLeft"
      }, "TopLeft"), /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "topCenter"
      }, "TopCenter"), /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "topRight"
      }, "TopRight"), /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "none"
      }, "None"))), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Pagination Bottom"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Radio.Group, {
        value: bottom,
        onChange: function onChange(e) {
          setBottom(e.target.value);
        }
      }, /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "bottomLeft"
      }, "BottomLeft"), /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "bottomCenter"
      }, "BottomCenter"), /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "bottomRight"
      }, "BottomRight"), /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "none"
      }, "None")))), /*#__PURE__*/_react["default"].createElement(_antd.Table, (0, _extends2["default"])({}, tableProps, {
        pagination: {
          position: [top, bottom]
        },
        columns: tableColumns,
        dataSource: hasData ? data : [],
        scroll: scroll
      })));
    };

    var _default = App;
    return _default;
  },
  loading: () => null
}),
    previewerProps: {"sources":{"_":{"tsx":"import { DownOutlined } from '@ant-design/icons';\nimport type { RadioChangeEvent } from 'antd';\nimport { Form, Radio, Space, Switch, Table } from 'antd';\nimport type { SizeType } from 'antd/es/config-provider/SizeContext';\nimport type { ColumnsType, TableProps } from 'antd/es/table';\nimport type { ExpandableConfig, TableRowSelection } from 'antd/es/table/interface';\nimport React, { useState } from 'react';\n\ninterface DataType {\n  key: number;\n  name: string;\n  age: number;\n  address: string;\n  description: string;\n}\n\ntype TablePaginationPosition =\n  | 'topLeft'\n  | 'topCenter'\n  | 'topRight'\n  | 'bottomLeft'\n  | 'bottomCenter'\n  | 'bottomRight';\n\nconst columns: ColumnsType<DataType> = [\n  {\n    title: 'Name',\n    dataIndex: 'name',\n  },\n  {\n    title: 'Age',\n    dataIndex: 'age',\n    sorter: (a, b) => a.age - b.age,\n  },\n  {\n    title: 'Address',\n    dataIndex: 'address',\n    filters: [\n      {\n        text: 'London',\n        value: 'London',\n      },\n      {\n        text: 'New York',\n        value: 'New York',\n      },\n    ],\n    onFilter: (value, record) => record.address.indexOf(value as string) === 0,\n  },\n  {\n    title: 'Action',\n    key: 'action',\n    sorter: true,\n    render: () => (\n      <Space size=\"middle\">\n        <a>Delete</a>\n        <a>\n          <Space>\n            More actions\n            <DownOutlined />\n          </Space>\n        </a>\n      </Space>\n    ),\n  },\n];\n\nconst data: DataType[] = [];\nfor (let i = 1; i <= 10; i++) {\n  data.push({\n    key: i,\n    name: 'John Brown',\n    age: Number(`${i}2`),\n    address: `New York No. ${i} Lake Park`,\n    description: `My name is John Brown, I am ${i}2 years old, living in New York No. ${i} Lake Park.`,\n  });\n}\n\nconst defaultExpandable = { expandedRowRender: (record: DataType) => <p>{record.description}</p> };\nconst defaultTitle = () => 'Here is title';\nconst defaultFooter = () => 'Here is footer';\n\nconst App: React.FC = () => {\n  const [bordered, setBordered] = useState(false);\n  const [loading, setLoading] = useState(false);\n  const [size, setSize] = useState<SizeType>('large');\n  const [expandable, setExpandable] = useState<ExpandableConfig<DataType> | undefined>(\n    defaultExpandable,\n  );\n  const [showTitle, setShowTitle] = useState(false);\n  const [showHeader, setShowHeader] = useState(true);\n  const [showfooter, setShowFooter] = useState(true);\n  const [rowSelection, setRowSelection] = useState<TableRowSelection<DataType> | undefined>({});\n  const [hasData, setHasData] = useState(true);\n  const [tableLayout, setTableLayout] = useState(undefined);\n  const [top, setTop] = useState<TablePaginationPosition | 'none'>('none');\n  const [bottom, setBottom] = useState<TablePaginationPosition>('bottomRight');\n  const [ellipsis, setEllipsis] = useState(false);\n  const [yScroll, setYScroll] = useState(false);\n  const [xScroll, setXScroll] = useState<string | undefined>(undefined);\n\n  const handleBorderChange = (enable: boolean) => {\n    setBordered(enable);\n  };\n\n  const handleLoadingChange = (enable: boolean) => {\n    setLoading(enable);\n  };\n\n  const handleSizeChange = (e: RadioChangeEvent) => {\n    setSize(e.target.value);\n  };\n\n  const handleTableLayoutChange = (e: RadioChangeEvent) => {\n    setTableLayout(e.target.value);\n  };\n\n  const handleExpandChange = (enable: boolean) => {\n    setExpandable(enable ? defaultExpandable : undefined);\n  };\n\n  const handleEllipsisChange = (enable: boolean) => {\n    setEllipsis(enable);\n  };\n\n  const handleTitleChange = (enable: boolean) => {\n    setShowTitle(enable);\n  };\n\n  const handleHeaderChange = (enable: boolean) => {\n    setShowHeader(enable);\n  };\n\n  const handleFooterChange = (enable: boolean) => {\n    setShowFooter(enable);\n  };\n\n  const handleRowSelectionChange = (enable: boolean) => {\n    setRowSelection(enable ? {} : undefined);\n  };\n\n  const handleYScrollChange = (enable: boolean) => {\n    setYScroll(enable);\n  };\n\n  const handleXScrollChange = (e: RadioChangeEvent) => {\n    setXScroll(e.target.value);\n  };\n\n  const handleDataChange = (newHasData: boolean) => {\n    setHasData(newHasData);\n  };\n\n  const scroll: { x?: number | string; y?: number | string } = {};\n  if (yScroll) {\n    scroll.y = 240;\n  }\n  if (xScroll) {\n    scroll.x = '100vw';\n  }\nconsole.log(scroll,'scroll');\n\n  const tableColumns = columns.map(item => ({ ...item, ellipsis }));\n  if (xScroll === 'fixed') {\n    tableColumns[0].fixed = true;\n    tableColumns[tableColumns.length - 1].fixed = 'right';\n  }\n\n  const tableProps: TableProps<DataType> = {\n    bordered,\n    loading,\n    size,\n    expandable,\n    title: showTitle ? defaultTitle : undefined,\n    showHeader,\n    footer: showfooter ? defaultFooter : undefined,\n    rowSelection,\n    scroll,\n    tableLayout,\n  };\n\n  return (\n    <>\n      <Form\n        layout=\"inline\"\n        className=\"components-table-demo-control-bar\"\n        style={{ marginBottom: 16 }}\n      >\n        <Form.Item label=\"Bordered\">\n          <Switch checked={bordered} onChange={handleBorderChange} />\n        </Form.Item>\n        <Form.Item label=\"loading\">\n          <Switch checked={loading} onChange={handleLoadingChange} />\n        </Form.Item>\n        <Form.Item label=\"Title\">\n          <Switch checked={showTitle} onChange={handleTitleChange} />\n        </Form.Item>\n        <Form.Item label=\"Column Header\">\n          <Switch checked={showHeader} onChange={handleHeaderChange} />\n        </Form.Item>\n        <Form.Item label=\"Footer\">\n          <Switch checked={showfooter} onChange={handleFooterChange} />\n        </Form.Item>\n        <Form.Item label=\"Expandable\">\n          <Switch checked={!!expandable} onChange={handleExpandChange} />\n        </Form.Item>\n        <Form.Item label=\"Checkbox\">\n          <Switch checked={!!rowSelection} onChange={handleRowSelectionChange} />\n        </Form.Item>\n        <Form.Item label=\"Fixed Header\">\n          <Switch checked={!!yScroll} onChange={handleYScrollChange} />\n        </Form.Item>\n        <Form.Item label=\"Has Data\">\n          <Switch checked={!!hasData} onChange={handleDataChange} />\n        </Form.Item>\n        <Form.Item label=\"Ellipsis\">\n          <Switch checked={!!ellipsis} onChange={handleEllipsisChange} />\n        </Form.Item>\n        <Form.Item label=\"Size\">\n          <Radio.Group value={size} onChange={handleSizeChange}>\n            <Radio.Button value=\"large\">Large</Radio.Button>\n            <Radio.Button value=\"middle\">Middle</Radio.Button>\n            <Radio.Button value=\"small\">Small</Radio.Button>\n          </Radio.Group>\n        </Form.Item>\n        <Form.Item label=\"Table Scroll\">\n          <Radio.Group value={xScroll} onChange={handleXScrollChange}>\n            <Radio.Button value={undefined}>Unset</Radio.Button>\n            <Radio.Button value=\"scroll\">Scroll</Radio.Button>\n            <Radio.Button value=\"fixed\">Fixed Columns</Radio.Button>\n          </Radio.Group>\n        </Form.Item>\n        <Form.Item label=\"Table Layout\">\n          <Radio.Group value={tableLayout} onChange={handleTableLayoutChange}>\n            <Radio.Button value={undefined}>Unset</Radio.Button>\n            <Radio.Button value=\"fixed\">Fixed</Radio.Button>\n          </Radio.Group>\n        </Form.Item>\n        <Form.Item label=\"Pagination Top\">\n          <Radio.Group\n            value={top}\n            onChange={e => {\n              setTop(e.target.value);\n            }}\n          >\n            <Radio.Button value=\"topLeft\">TopLeft</Radio.Button>\n            <Radio.Button value=\"topCenter\">TopCenter</Radio.Button>\n            <Radio.Button value=\"topRight\">TopRight</Radio.Button>\n            <Radio.Button value=\"none\">None</Radio.Button>\n          </Radio.Group>\n        </Form.Item>\n        <Form.Item label=\"Pagination Bottom\">\n          <Radio.Group\n            value={bottom}\n            onChange={e => {\n              setBottom(e.target.value);\n            }}\n          >\n            <Radio.Button value=\"bottomLeft\">BottomLeft</Radio.Button>\n            <Radio.Button value=\"bottomCenter\">BottomCenter</Radio.Button>\n            <Radio.Button value=\"bottomRight\">BottomRight</Radio.Button>\n            <Radio.Button value=\"none\">None</Radio.Button>\n          </Radio.Group>\n        </Form.Item>\n      </Form>\n      <Table\n        {...tableProps}\n        pagination={{ position: [top as TablePaginationPosition, bottom] }}\n        columns={tableColumns}\n        dataSource={hasData ? data : []}\n        scroll={scroll}\n      />\n    </>\n  );\n};\n\nexport default App;\n"}},"dependencies":{"@ant-design/icons":{"version":"4.7.0"},"antd":{"version":"4.24.2","css":"antd/dist/antd.css"},"react":{"version":">=16.9.0"},"react-dom":{"version":">=16.9.0"}},"componentName":"EditTableHeader","identifier":"EditTableHeader-1-demo"},
  },
  'components-test': {
    component: dynamic({
      loader: async () => (await import(/* webpackChunkName: "demos_tseT" */'F:/LYH_work/mycode/my-markdown/src/Components/Test/index.tsx')).default,
      loading: () => null,
    }),
    previewerProps: {"sources":{"_":{"tsx":rawCode2},"demo.tsx":{"import":"./demo","content":rawCode3},"demo.less":{"import":"./demo.less","content":rawCode4},"FileListItem.tsx":{"import":"./FileListItem","content":rawCode5},"FileListItem.less":{"import":"./FileListItem.less","content":rawCode6}},"dependencies":{"antd":{"version":"4.24.2","css":"antd/dist/antd.css"},"react":{"version":"16.14.0"},"react-dom":{"version":">=16.9.0"},"lodash":{"version":"4.17.21"}},"componentName":"Test","identifier":"components-test"},
  },
  'Test-1-demo': {
    component: dynamic({
  loader: async function () {
    var _interopRequireWildcard = require("F:/LYH_work/mycode/my-markdown/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireWildcard.js")["default"];

    var _interopRequireDefault = require("F:/LYH_work/mycode/my-markdown/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireDefault.js")["default"];

    var _extends2 = _interopRequireDefault(await import("F:/LYH_work/mycode/my-markdown/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/extends.js"));

    var _objectSpread2 = _interopRequireDefault(await import("F:/LYH_work/mycode/my-markdown/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/objectSpread2.js"));

    var _slicedToArray2 = _interopRequireDefault(await import("F:/LYH_work/mycode/my-markdown/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/slicedToArray.js"));

    var _icons = await import("@ant-design/icons");

    var _antd = await import("antd");

    var _react = _interopRequireWildcard(await import("react"));

    var columns = [{
      title: 'Name',
      dataIndex: 'name'
    }, {
      title: 'Age',
      dataIndex: 'age',
      sorter: function sorter(a, b) {
        return a.age - b.age;
      }
    }, {
      title: 'Address',
      dataIndex: 'address',
      filters: [{
        text: 'London',
        value: 'London'
      }, {
        text: 'New York',
        value: 'New York'
      }],
      onFilter: function onFilter(value, record) {
        return record.address.indexOf(value) === 0;
      }
    }, {
      title: 'Action',
      key: 'action',
      sorter: true,
      render: function render() {
        return /*#__PURE__*/_react["default"].createElement(_antd.Space, {
          size: "middle"
        }, /*#__PURE__*/_react["default"].createElement("a", null, "Delete"), /*#__PURE__*/_react["default"].createElement("a", null, /*#__PURE__*/_react["default"].createElement(_antd.Space, null, "More actions", /*#__PURE__*/_react["default"].createElement(_icons.DownOutlined, null))));
      }
    }];
    var data = [];

    for (var i = 1; i <= 10; i++) {
      data.push({
        key: i,
        name: 'John Brown',
        age: Number("".concat(i, "2")),
        address: "New York No. ".concat(i, " Lake Park"),
        description: "My name is John Brown, I am ".concat(i, "2 years old, living in New York No. ").concat(i, " Lake Park.")
      });
    }

    var defaultExpandable = {
      expandedRowRender: function expandedRowRender(record) {
        return /*#__PURE__*/_react["default"].createElement("p", null, record.description);
      }
    };

    var defaultTitle = function defaultTitle() {
      return 'Here is title';
    };

    var defaultFooter = function defaultFooter() {
      return 'Here is footer';
    };

    var App = function App() {
      var _useState = (0, _react.useState)(false),
          _useState2 = (0, _slicedToArray2["default"])(_useState, 2),
          bordered = _useState2[0],
          setBordered = _useState2[1];

      var _useState3 = (0, _react.useState)(false),
          _useState4 = (0, _slicedToArray2["default"])(_useState3, 2),
          loading = _useState4[0],
          setLoading = _useState4[1];

      var _useState5 = (0, _react.useState)('large'),
          _useState6 = (0, _slicedToArray2["default"])(_useState5, 2),
          size = _useState6[0],
          setSize = _useState6[1];

      var _useState7 = (0, _react.useState)(defaultExpandable),
          _useState8 = (0, _slicedToArray2["default"])(_useState7, 2),
          expandable = _useState8[0],
          setExpandable = _useState8[1];

      var _useState9 = (0, _react.useState)(false),
          _useState10 = (0, _slicedToArray2["default"])(_useState9, 2),
          showTitle = _useState10[0],
          setShowTitle = _useState10[1];

      var _useState11 = (0, _react.useState)(true),
          _useState12 = (0, _slicedToArray2["default"])(_useState11, 2),
          showHeader = _useState12[0],
          setShowHeader = _useState12[1];

      var _useState13 = (0, _react.useState)(true),
          _useState14 = (0, _slicedToArray2["default"])(_useState13, 2),
          showfooter = _useState14[0],
          setShowFooter = _useState14[1];

      var _useState15 = (0, _react.useState)({}),
          _useState16 = (0, _slicedToArray2["default"])(_useState15, 2),
          rowSelection = _useState16[0],
          setRowSelection = _useState16[1];

      var _useState17 = (0, _react.useState)(true),
          _useState18 = (0, _slicedToArray2["default"])(_useState17, 2),
          hasData = _useState18[0],
          setHasData = _useState18[1];

      var _useState19 = (0, _react.useState)(undefined),
          _useState20 = (0, _slicedToArray2["default"])(_useState19, 2),
          tableLayout = _useState20[0],
          setTableLayout = _useState20[1];

      var _useState21 = (0, _react.useState)('none'),
          _useState22 = (0, _slicedToArray2["default"])(_useState21, 2),
          top = _useState22[0],
          setTop = _useState22[1];

      var _useState23 = (0, _react.useState)('bottomRight'),
          _useState24 = (0, _slicedToArray2["default"])(_useState23, 2),
          bottom = _useState24[0],
          setBottom = _useState24[1];

      var _useState25 = (0, _react.useState)(false),
          _useState26 = (0, _slicedToArray2["default"])(_useState25, 2),
          ellipsis = _useState26[0],
          setEllipsis = _useState26[1];

      var _useState27 = (0, _react.useState)(false),
          _useState28 = (0, _slicedToArray2["default"])(_useState27, 2),
          yScroll = _useState28[0],
          setYScroll = _useState28[1];

      var _useState29 = (0, _react.useState)(undefined),
          _useState30 = (0, _slicedToArray2["default"])(_useState29, 2),
          xScroll = _useState30[0],
          setXScroll = _useState30[1];

      var handleBorderChange = function handleBorderChange(enable) {
        setBordered(enable);
      };

      var handleLoadingChange = function handleLoadingChange(enable) {
        setLoading(enable);
      };

      var handleSizeChange = function handleSizeChange(e) {
        setSize(e.target.value);
      };

      var handleTableLayoutChange = function handleTableLayoutChange(e) {
        setTableLayout(e.target.value);
      };

      var handleExpandChange = function handleExpandChange(enable) {
        setExpandable(enable ? defaultExpandable : undefined);
      };

      var handleEllipsisChange = function handleEllipsisChange(enable) {
        setEllipsis(enable);
      };

      var handleTitleChange = function handleTitleChange(enable) {
        setShowTitle(enable);
      };

      var handleHeaderChange = function handleHeaderChange(enable) {
        setShowHeader(enable);
      };

      var handleFooterChange = function handleFooterChange(enable) {
        setShowFooter(enable);
      };

      var handleRowSelectionChange = function handleRowSelectionChange(enable) {
        setRowSelection(enable ? {} : undefined);
      };

      var handleYScrollChange = function handleYScrollChange(enable) {
        setYScroll(enable);
      };

      var handleXScrollChange = function handleXScrollChange(e) {
        setXScroll(e.target.value);
      };

      var handleDataChange = function handleDataChange(newHasData) {
        setHasData(newHasData);
      };

      var scroll = {};

      if (yScroll) {
        scroll.y = 240;
      }

      if (xScroll) {
        scroll.x = '100vw';
      }

      console.log(scroll, 'scroll');
      var tableColumns = columns.map(function (item) {
        return (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, item), {}, {
          ellipsis: ellipsis
        });
      });

      if (xScroll === 'fixed') {
        tableColumns[0].fixed = true;
        tableColumns[tableColumns.length - 1].fixed = 'right';
      }

      var tableProps = {
        bordered: bordered,
        loading: loading,
        size: size,
        expandable: expandable,
        title: showTitle ? defaultTitle : undefined,
        showHeader: showHeader,
        footer: showfooter ? defaultFooter : undefined,
        rowSelection: rowSelection,
        scroll: scroll,
        tableLayout: tableLayout
      };
      return /*#__PURE__*/_react["default"].createElement(_react["default"].Fragment, null, /*#__PURE__*/_react["default"].createElement(_antd.Form, {
        layout: "inline",
        className: "components-table-demo-control-bar",
        style: {
          marginBottom: 16
        }
      }, /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Bordered"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Switch, {
        checked: bordered,
        onChange: handleBorderChange
      })), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "loading"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Switch, {
        checked: loading,
        onChange: handleLoadingChange
      })), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Title"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Switch, {
        checked: showTitle,
        onChange: handleTitleChange
      })), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Column Header"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Switch, {
        checked: showHeader,
        onChange: handleHeaderChange
      })), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Footer"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Switch, {
        checked: showfooter,
        onChange: handleFooterChange
      })), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Expandable"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Switch, {
        checked: !!expandable,
        onChange: handleExpandChange
      })), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Checkbox"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Switch, {
        checked: !!rowSelection,
        onChange: handleRowSelectionChange
      })), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Fixed Header"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Switch, {
        checked: !!yScroll,
        onChange: handleYScrollChange
      })), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Has Data"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Switch, {
        checked: !!hasData,
        onChange: handleDataChange
      })), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Ellipsis"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Switch, {
        checked: !!ellipsis,
        onChange: handleEllipsisChange
      })), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Size"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Radio.Group, {
        value: size,
        onChange: handleSizeChange
      }, /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "large"
      }, "Large"), /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "middle"
      }, "Middle"), /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "small"
      }, "Small"))), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Table Scroll"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Radio.Group, {
        value: xScroll,
        onChange: handleXScrollChange
      }, /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: undefined
      }, "Unset"), /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "scroll"
      }, "Scroll"), /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "fixed"
      }, "Fixed Columns"))), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Table Layout"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Radio.Group, {
        value: tableLayout,
        onChange: handleTableLayoutChange
      }, /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: undefined
      }, "Unset"), /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "fixed"
      }, "Fixed"))), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Pagination Top"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Radio.Group, {
        value: top,
        onChange: function onChange(e) {
          setTop(e.target.value);
        }
      }, /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "topLeft"
      }, "TopLeft"), /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "topCenter"
      }, "TopCenter"), /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "topRight"
      }, "TopRight"), /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "none"
      }, "None"))), /*#__PURE__*/_react["default"].createElement(_antd.Form.Item, {
        label: "Pagination Bottom"
      }, /*#__PURE__*/_react["default"].createElement(_antd.Radio.Group, {
        value: bottom,
        onChange: function onChange(e) {
          setBottom(e.target.value);
        }
      }, /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "bottomLeft"
      }, "BottomLeft"), /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "bottomCenter"
      }, "BottomCenter"), /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "bottomRight"
      }, "BottomRight"), /*#__PURE__*/_react["default"].createElement(_antd.Radio.Button, {
        value: "none"
      }, "None")))), /*#__PURE__*/_react["default"].createElement(_antd.Table, (0, _extends2["default"])({}, tableProps, {
        pagination: {
          position: [top, bottom]
        },
        columns: tableColumns,
        dataSource: hasData ? data : [],
        scroll: scroll
      })));
    };

    var _default = App;
    return _default;
  },
  loading: () => null
}),
    previewerProps: {"sources":{"_":{"tsx":"import { DownOutlined } from '@ant-design/icons';\nimport type { RadioChangeEvent } from 'antd';\nimport { Form, Radio, Space, Switch, Table } from 'antd';\nimport type { SizeType } from 'antd/es/config-provider/SizeContext';\nimport type { ColumnsType, TableProps } from 'antd/es/table';\nimport type { ExpandableConfig, TableRowSelection } from 'antd/es/table/interface';\nimport React, { useState } from 'react';\n\ninterface DataType {\n  key: number;\n  name: string;\n  age: number;\n  address: string;\n  description: string;\n}\n\ntype TablePaginationPosition =\n  | 'topLeft'\n  | 'topCenter'\n  | 'topRight'\n  | 'bottomLeft'\n  | 'bottomCenter'\n  | 'bottomRight';\n\nconst columns: ColumnsType<DataType> = [\n  {\n    title: 'Name',\n    dataIndex: 'name',\n  },\n  {\n    title: 'Age',\n    dataIndex: 'age',\n    sorter: (a, b) => a.age - b.age,\n  },\n  {\n    title: 'Address',\n    dataIndex: 'address',\n    filters: [\n      {\n        text: 'London',\n        value: 'London',\n      },\n      {\n        text: 'New York',\n        value: 'New York',\n      },\n    ],\n    onFilter: (value, record) => record.address.indexOf(value as string) === 0,\n  },\n  {\n    title: 'Action',\n    key: 'action',\n    sorter: true,\n    render: () => (\n      <Space size=\"middle\">\n        <a>Delete</a>\n        <a>\n          <Space>\n            More actions\n            <DownOutlined />\n          </Space>\n        </a>\n      </Space>\n    ),\n  },\n];\n\nconst data: DataType[] = [];\nfor (let i = 1; i <= 10; i++) {\n  data.push({\n    key: i,\n    name: 'John Brown',\n    age: Number(`${i}2`),\n    address: `New York No. ${i} Lake Park`,\n    description: `My name is John Brown, I am ${i}2 years old, living in New York No. ${i} Lake Park.`,\n  });\n}\n\nconst defaultExpandable = { expandedRowRender: (record: DataType) => <p>{record.description}</p> };\nconst defaultTitle = () => 'Here is title';\nconst defaultFooter = () => 'Here is footer';\n\nconst App: React.FC = () => {\n  const [bordered, setBordered] = useState(false);\n  const [loading, setLoading] = useState(false);\n  const [size, setSize] = useState<SizeType>('large');\n  const [expandable, setExpandable] = useState<ExpandableConfig<DataType> | undefined>(\n    defaultExpandable,\n  );\n  const [showTitle, setShowTitle] = useState(false);\n  const [showHeader, setShowHeader] = useState(true);\n  const [showfooter, setShowFooter] = useState(true);\n  const [rowSelection, setRowSelection] = useState<TableRowSelection<DataType> | undefined>({});\n  const [hasData, setHasData] = useState(true);\n  const [tableLayout, setTableLayout] = useState(undefined);\n  const [top, setTop] = useState<TablePaginationPosition | 'none'>('none');\n  const [bottom, setBottom] = useState<TablePaginationPosition>('bottomRight');\n  const [ellipsis, setEllipsis] = useState(false);\n  const [yScroll, setYScroll] = useState(false);\n  const [xScroll, setXScroll] = useState<string | undefined>(undefined);\n\n  const handleBorderChange = (enable: boolean) => {\n    setBordered(enable);\n  };\n\n  const handleLoadingChange = (enable: boolean) => {\n    setLoading(enable);\n  };\n\n  const handleSizeChange = (e: RadioChangeEvent) => {\n    setSize(e.target.value);\n  };\n\n  const handleTableLayoutChange = (e: RadioChangeEvent) => {\n    setTableLayout(e.target.value);\n  };\n\n  const handleExpandChange = (enable: boolean) => {\n    setExpandable(enable ? defaultExpandable : undefined);\n  };\n\n  const handleEllipsisChange = (enable: boolean) => {\n    setEllipsis(enable);\n  };\n\n  const handleTitleChange = (enable: boolean) => {\n    setShowTitle(enable);\n  };\n\n  const handleHeaderChange = (enable: boolean) => {\n    setShowHeader(enable);\n  };\n\n  const handleFooterChange = (enable: boolean) => {\n    setShowFooter(enable);\n  };\n\n  const handleRowSelectionChange = (enable: boolean) => {\n    setRowSelection(enable ? {} : undefined);\n  };\n\n  const handleYScrollChange = (enable: boolean) => {\n    setYScroll(enable);\n  };\n\n  const handleXScrollChange = (e: RadioChangeEvent) => {\n    setXScroll(e.target.value);\n  };\n\n  const handleDataChange = (newHasData: boolean) => {\n    setHasData(newHasData);\n  };\n\n  const scroll: { x?: number | string; y?: number | string } = {};\n  if (yScroll) {\n    scroll.y = 240;\n  }\n  if (xScroll) {\n    scroll.x = '100vw';\n  }\nconsole.log(scroll,'scroll');\n\n  const tableColumns = columns.map(item => ({ ...item, ellipsis }));\n  if (xScroll === 'fixed') {\n    tableColumns[0].fixed = true;\n    tableColumns[tableColumns.length - 1].fixed = 'right';\n  }\n\n  const tableProps: TableProps<DataType> = {\n    bordered,\n    loading,\n    size,\n    expandable,\n    title: showTitle ? defaultTitle : undefined,\n    showHeader,\n    footer: showfooter ? defaultFooter : undefined,\n    rowSelection,\n    scroll,\n    tableLayout,\n  };\n\n  return (\n    <>\n      <Form\n        layout=\"inline\"\n        className=\"components-table-demo-control-bar\"\n        style={{ marginBottom: 16 }}\n      >\n        <Form.Item label=\"Bordered\">\n          <Switch checked={bordered} onChange={handleBorderChange} />\n        </Form.Item>\n        <Form.Item label=\"loading\">\n          <Switch checked={loading} onChange={handleLoadingChange} />\n        </Form.Item>\n        <Form.Item label=\"Title\">\n          <Switch checked={showTitle} onChange={handleTitleChange} />\n        </Form.Item>\n        <Form.Item label=\"Column Header\">\n          <Switch checked={showHeader} onChange={handleHeaderChange} />\n        </Form.Item>\n        <Form.Item label=\"Footer\">\n          <Switch checked={showfooter} onChange={handleFooterChange} />\n        </Form.Item>\n        <Form.Item label=\"Expandable\">\n          <Switch checked={!!expandable} onChange={handleExpandChange} />\n        </Form.Item>\n        <Form.Item label=\"Checkbox\">\n          <Switch checked={!!rowSelection} onChange={handleRowSelectionChange} />\n        </Form.Item>\n        <Form.Item label=\"Fixed Header\">\n          <Switch checked={!!yScroll} onChange={handleYScrollChange} />\n        </Form.Item>\n        <Form.Item label=\"Has Data\">\n          <Switch checked={!!hasData} onChange={handleDataChange} />\n        </Form.Item>\n        <Form.Item label=\"Ellipsis\">\n          <Switch checked={!!ellipsis} onChange={handleEllipsisChange} />\n        </Form.Item>\n        <Form.Item label=\"Size\">\n          <Radio.Group value={size} onChange={handleSizeChange}>\n            <Radio.Button value=\"large\">Large</Radio.Button>\n            <Radio.Button value=\"middle\">Middle</Radio.Button>\n            <Radio.Button value=\"small\">Small</Radio.Button>\n          </Radio.Group>\n        </Form.Item>\n        <Form.Item label=\"Table Scroll\">\n          <Radio.Group value={xScroll} onChange={handleXScrollChange}>\n            <Radio.Button value={undefined}>Unset</Radio.Button>\n            <Radio.Button value=\"scroll\">Scroll</Radio.Button>\n            <Radio.Button value=\"fixed\">Fixed Columns</Radio.Button>\n          </Radio.Group>\n        </Form.Item>\n        <Form.Item label=\"Table Layout\">\n          <Radio.Group value={tableLayout} onChange={handleTableLayoutChange}>\n            <Radio.Button value={undefined}>Unset</Radio.Button>\n            <Radio.Button value=\"fixed\">Fixed</Radio.Button>\n          </Radio.Group>\n        </Form.Item>\n        <Form.Item label=\"Pagination Top\">\n          <Radio.Group\n            value={top}\n            onChange={e => {\n              setTop(e.target.value);\n            }}\n          >\n            <Radio.Button value=\"topLeft\">TopLeft</Radio.Button>\n            <Radio.Button value=\"topCenter\">TopCenter</Radio.Button>\n            <Radio.Button value=\"topRight\">TopRight</Radio.Button>\n            <Radio.Button value=\"none\">None</Radio.Button>\n          </Radio.Group>\n        </Form.Item>\n        <Form.Item label=\"Pagination Bottom\">\n          <Radio.Group\n            value={bottom}\n            onChange={e => {\n              setBottom(e.target.value);\n            }}\n          >\n            <Radio.Button value=\"bottomLeft\">BottomLeft</Radio.Button>\n            <Radio.Button value=\"bottomCenter\">BottomCenter</Radio.Button>\n            <Radio.Button value=\"bottomRight\">BottomRight</Radio.Button>\n            <Radio.Button value=\"none\">None</Radio.Button>\n          </Radio.Group>\n        </Form.Item>\n      </Form>\n      <Table\n        {...tableProps}\n        pagination={{ position: [top as TablePaginationPosition, bottom] }}\n        columns={tableColumns}\n        dataSource={hasData ? data : []}\n        scroll={scroll}\n      />\n    </>\n  );\n};\n\nexport default App;\n"}},"dependencies":{"@ant-design/icons":{"version":"4.7.0"},"antd":{"version":"4.24.2","css":"antd/dist/antd.css"},"react":{"version":">=16.9.0"},"react-dom":{"version":">=16.9.0"}},"componentName":"Test","identifier":"Test-1-demo"},
  },
  'leaflet-demo': {
    component: dynamic({
      loader: async () => (await import(/* webpackChunkName: "demos_no_comp" */'F:/LYH_work/mycode/my-markdown/docs/map/Leaflet/demo.tsx')).default,
      loading: () => null,
    }),
    previewerProps: {"sources":{"_":{"tsx":rawCode7}},"dependencies":{"react":{"version":"16.14.0"},"leaflet":{"version":"1.9.1","css":"leaflet/dist/leaflet.css"}},"transform":true,"identifier":"leaflet-demo"},
  },
  'mapbox-mapboxsync': {
    component: dynamic({
      loader: async () => (await import(/* webpackChunkName: "demos_no_comp" */'F:/LYH_work/mycode/my-markdown/docs/map/Mapbox/mapboxSync.tsx')).default,
      loading: () => null,
    }),
    previewerProps: {"sources":{"_":{"tsx":rawCode8}},"dependencies":{},"identifier":"mapbox-mapboxsync"},
  },
  'components-autoscrolllist': {
    component: dynamic({
      loader: async () => (await import(/* webpackChunkName: "demos_tsiLllorcSotuA" */'F:/LYH_work/mycode/my-markdown/src/Components/AutoScrollList/index.tsx')).default,
      loading: () => null,
    }),
    previewerProps: {"sources":{"_":{"tsx":rawCode9}},"dependencies":{},"componentName":"AutoScrollList","identifier":"components-autoscrolllist"},
  },
};
