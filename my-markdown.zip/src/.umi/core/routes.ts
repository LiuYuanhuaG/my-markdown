// @ts-nocheck
import React from 'react';
import { ApplyPluginsType, dynamic } from 'F:/LYH_work/mycode/my-markdown/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';
import LoadingComponent from '@/Loading';

export function getRoutes() {
  const routes = [
  {
    "path": "/~demos/:uuid",
    "layout": false,
    "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'../dumi/layout'), loading: LoadingComponent})],
    "component": ((props) => dynamic({
          loader: async () => {
            const React = await import('react');
            const { default: getDemoRenderArgs } = await import(/* webpackChunkName: 'dumi_demos' */ 'F:/LYH_work/mycode/my-markdown/node_modules/@umijs/preset-dumi/lib/plugins/features/demo/getDemoRenderArgs');
            const { default: Previewer } = await import(/* webpackChunkName: 'dumi_demos' */ 'dumi-theme-default/es/builtins/Previewer.js');
            const { usePrefersColor, context } = await import(/* webpackChunkName: 'dumi_demos' */ 'dumi/theme');

            return props => {
              
      const { demos } = React.useContext(context);
      const [renderArgs, setRenderArgs] = React.useState([]);

      // update render args when props changed
      React.useLayoutEffect(() => {
        setRenderArgs(getDemoRenderArgs(props, demos));
      }, [props.match.params.uuid, props.location.query.wrapper, props.location.query.capture]);

      // for listen prefers-color-schema media change in demo single route
      usePrefersColor();

      switch (renderArgs.length) {
        case 1:
          // render demo directly
          return renderArgs[0];

        case 2:
          // render demo with previewer
          return React.createElement(
            Previewer,
            renderArgs[0],
            renderArgs[1],
          );

        default:
          return `Demo ${props.match.params.uuid} not found :(`;
      }
    
            }
          },
          loading: () => null,
        }))()
  },
  {
    "path": "/_demos/:uuid",
    "redirect": "/~demos/:uuid"
  },
  {
    "__dumiRoot": true,
    "layout": false,
    "path": "/",
    "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'../dumi/layout'), loading: LoadingComponent}), dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'F:/LYH_work/mycode/my-markdown/node_modules/dumi-theme-default/es/layout.js'), loading: LoadingComponent})],
    "routes": [
      {
        "path": "/zh-CN",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'README.zh-CN.md' */'F:/LYH_work/mycode/my-markdown/README.zh-CN.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "locale": "zh-CN",
          "order": null,
          "filePath": "README.zh-CN.md",
          "updatedTime": 1668592556000,
          "slugs": [
            {
              "depth": 1,
              "value": "🌟 欢迎来到前端病情院",
              "heading": "-欢迎来到前端病情院"
            },
            {
              "depth": 2,
              "value": "🚀 这里有什么?",
              "heading": "-这里有什么"
            },
            {
              "depth": 2,
              "value": "✨ 游览病院？",
              "heading": "-游览病院"
            },
            {
              "depth": 2,
              "value": "📒 本院聘请dumi建筑供材",
              "heading": "-本院聘请dumi建筑供材"
            },
            {
              "depth": 2,
              "value": "🤖 命令介绍",
              "heading": "-命令介绍"
            },
            {
              "depth": 2,
              "value": "交流群",
              "heading": "交流群"
            },
            {
              "depth": 2,
              "value": "联系院长",
              "heading": "联系院长"
            },
            {
              "depth": 2,
              "value": "给院长投食",
              "heading": "给院长投食"
            }
          ],
          "title": "🌟 欢迎来到前端病情院"
        },
        "title": "🌟 欢迎来到前端病情院"
      },
      {
        "path": "/",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'README.md' */'F:/LYH_work/mycode/my-markdown/README.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "locale": "en-US",
          "order": null,
          "filePath": "README.md",
          "updatedTime": 1668592556000,
          "slugs": [
            {
              "depth": 1,
              "value": "🌟 Welcome to Web Front End Hospital",
              "heading": "-welcome-to-web-front-end-hospital"
            },
            {
              "depth": 2,
              "value": "🚀 What's in here?",
              "heading": "-whats-in-here"
            },
            {
              "depth": 2,
              "value": "✨Tour the hospital?",
              "heading": "tour-the-hospital"
            },
            {
              "depth": 2,
              "value": "📒 Our hospital hires dumi for building materials",
              "heading": "-our-hospital-hires-dumi-for-building-materials"
            },
            {
              "depth": 2,
              "value": "🤖 Command introduction",
              "heading": "-command-introduction"
            },
            {
              "depth": 2,
              "value": "Discuss group",
              "heading": "discuss-group"
            },
            {
              "depth": 2,
              "value": "",
              "heading": ""
            },
            {
              "depth": 2,
              "value": "联系院长",
              "heading": "联系院长"
            },
            {
              "depth": 2,
              "value": "给院长投食",
              "heading": "给院长投食"
            },
            {
              "depth": 2,
              "value": "",
              "heading": "-1"
            }
          ],
          "title": "🌟 Welcome to Web Front End Hospital"
        },
        "title": "🌟 Welcome to Web Front End Hospital"
      },
      {
        "path": "/components/AutoScrollList/auto-scroll-list",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'Components__AutoScrollList__index.md' */'F:/LYH_work/mycode/my-markdown/src/Components/AutoScrollList/index.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "src/Components/AutoScrollList/index.md",
          "updatedTime": 1669704228376,
          "componentName": "AutoScrollList",
          "nav": {
            "path": "/components",
            "title": "Components"
          },
          "group": {
            "path": "/components/AutoScrollList",
            "title": "AutoScrollList"
          },
          "slugs": [
            {
              "depth": 1,
              "value": "AutoScrollList",
              "heading": "autoscrolllist"
            }
          ],
          "title": "AutoScrollList",
          "hasPreviewer": true
        },
        "title": "AutoScrollList - 知识海洋里的淡水鱼"
      },
      {
        "path": "/components/EditTableHeader/edit-table-header",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'Components__EditTableHeader__index.md' */'F:/LYH_work/mycode/my-markdown/src/Components/EditTableHeader/index.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "src/Components/EditTableHeader/index.md",
          "updatedTime": 1668592556000,
          "componentName": "EditTableHeader",
          "nav": {
            "title": "Components",
            "path": "/components"
          },
          "group": {
            "path": "/components/EditTableHeader",
            "title": "EditTableHeader"
          },
          "slugs": [
            {
              "depth": 1,
              "value": "EditTableHeader",
              "heading": "edittableheader"
            }
          ],
          "title": "EditTableHeader",
          "hasPreviewer": true
        },
        "title": "EditTableHeader - 知识海洋里的淡水鱼"
      },
      {
        "path": "/zh-CN/components/EditTableHeader/edit-table-header",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'Components__EditTableHeader__index.zh-CN.md' */'F:/LYH_work/mycode/my-markdown/src/Components/EditTableHeader/index.zh-CN.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "src/Components/EditTableHeader/index.zh-CN.md",
          "updatedTime": 1668592556000,
          "componentName": "EditTableHeader",
          "nav": {
            "title": "Components",
            "path": "/zh-CN/components"
          },
          "group": {
            "path": "/zh-CN/components/EditTableHeader",
            "title": "EditTableHeader"
          },
          "slugs": [
            {
              "depth": 2,
              "value": "EditTableHeader",
              "heading": "edittableheader"
            }
          ],
          "title": "EditTableHeader",
          "hasPreviewer": true,
          "locale": "zh-CN"
        },
        "title": "EditTableHeader - 知识海洋里的淡水鱼"
      },
      {
        "path": "/components/Test/test",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'Components__Test__index.md' */'F:/LYH_work/mycode/my-markdown/src/Components/Test/index.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "src/Components/Test/index.md",
          "updatedTime": 1668592556000,
          "componentName": "Test",
          "nav": {
            "path": "/components",
            "title": "Components"
          },
          "group": {
            "path": "/components/Test",
            "title": "Test"
          },
          "slugs": [
            {
              "depth": 1,
              "value": "Test",
              "heading": "test"
            }
          ],
          "title": "Test",
          "hasPreviewer": true
        },
        "title": "Test - 知识海洋里的淡水鱼"
      },
      {
        "path": "/zh-CN/components/Test/test",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'Components__Test__index.zh-CN.md' */'F:/LYH_work/mycode/my-markdown/src/Components/Test/index.zh-CN.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "src/Components/Test/index.zh-CN.md",
          "updatedTime": 1668592556000,
          "componentName": "Test",
          "nav": {
            "path": "/zh-CN/components",
            "title": "Components"
          },
          "group": {
            "path": "/zh-CN/components/Test",
            "title": "Test"
          },
          "slugs": [
            {
              "depth": 1,
              "value": "Test",
              "heading": "test"
            }
          ],
          "title": "Test",
          "hasPreviewer": true,
          "locale": "zh-CN"
        },
        "title": "Test - 知识海洋里的淡水鱼"
      },
      {
        "path": "/guide",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'docs__guide__index.md' */'F:/LYH_work/mycode/my-markdown/docs/guide/index.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "docs/guide/index.md",
          "updatedTime": 1663839587000,
          "title": "总览",
          "order": 1,
          "nav": {
            "title": "前端之路",
            "order": 1,
            "path": "/guide"
          },
          "slugs": [
            {
              "depth": 2,
              "value": "1. 2022-plan",
              "heading": "1-2022-plan"
            },
            {
              "depth": 2,
              "value": "2. 需要掌握的基本规范",
              "heading": "2-需要掌握的基本规范"
            },
            {
              "depth": 2,
              "value": "3. CSS",
              "heading": "3-css"
            },
            {
              "depth": 2,
              "value": "4.写文档的工具",
              "heading": "4写文档的工具"
            },
            {
              "depth": 2,
              "value": "5. 前端工程化",
              "heading": "5-前端工程化"
            },
            {
              "depth": 2,
              "value": "6. 运维相关",
              "heading": "6-运维相关"
            },
            {
              "depth": 2,
              "value": "7. 单元测试",
              "heading": "7-单元测试"
            },
            {
              "depth": 2,
              "value": "8. 实践操作",
              "heading": "8-实践操作"
            },
            {
              "depth": 2,
              "value": "9. react 及周边",
              "heading": "9-react-及周边"
            },
            {
              "depth": 2,
              "value": "10. vue 及周边",
              "heading": "10-vue-及周边"
            },
            {
              "depth": 2,
              "value": "11. 微信小程序",
              "heading": "11-微信小程序"
            },
            {
              "depth": 2,
              "value": "12. typescript",
              "heading": "12-typescript"
            },
            {
              "depth": 2,
              "value": "13. 源码",
              "heading": "13-源码"
            },
            {
              "depth": 2,
              "value": "14. 可视化",
              "heading": "14-可视化"
            },
            {
              "depth": 2,
              "value": "15. gis",
              "heading": "15-gis"
            },
            {
              "depth": 2,
              "value": "16. 前端的其他 API",
              "heading": "16-前端的其他-api"
            },
            {
              "depth": 2,
              "value": "17. 项目难点",
              "heading": "17-项目难点"
            },
            {
              "depth": 2,
              "value": "18. 设计模式",
              "heading": "18-设计模式"
            },
            {
              "depth": 2,
              "value": "19. 算法",
              "heading": "19-算法"
            },
            {
              "depth": 2,
              "value": "20. 有意思的库",
              "heading": "20-有意思的库"
            },
            {
              "depth": 2,
              "value": "21.macos 相关",
              "heading": "21macos-相关"
            }
          ]
        },
        "title": "总览 - 知识海洋里的淡水鱼"
      },
      {
        "path": "/guide/type-script进阶文章",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'docs__guide__TypeScript进阶文章__index.md' */'F:/LYH_work/mycode/my-markdown/docs/guide/TypeScript进阶文章/index.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "docs/guide/TypeScript进阶文章/index.md",
          "updatedTime": 1663839587000,
          "title": "TypeScript进阶文章",
          "order": 1,
          "nav": {
            "title": "前端之路",
            "order": 1,
            "path": "/guide"
          },
          "slugs": [
            {
              "depth": 2,
              "value": "TypeScript 进阶文章",
              "heading": "typescript-进阶文章"
            },
            {
              "depth": 2,
              "value": "其他文档",
              "heading": "其他文档"
            }
          ],
          "group": {
            "path": "/guide/type-script进阶文章",
            "title": "TypeScript进阶文章"
          }
        },
        "title": "TypeScript进阶文章 - 知识海洋里的淡水鱼"
      },
      {
        "path": "/guide/基础知识js/内置对象",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'docs__guide__基础知识js__内置对象.md' */'F:/LYH_work/mycode/my-markdown/docs/guide/基础知识js/内置对象.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "docs/guide/基础知识js/内置对象.md",
          "updatedTime": 1668592556000,
          "slugs": [
            {
              "depth": 1,
              "value": "内置对象",
              "heading": "内置对象"
            },
            {
              "depth": 2,
              "value": "值属性",
              "heading": "值属性"
            },
            {
              "depth": 3,
              "value": "Infinity",
              "heading": "infinity"
            },
            {
              "depth": 3,
              "value": "NaN",
              "heading": "nan"
            },
            {
              "depth": 3,
              "value": "undefined",
              "heading": "undefined"
            },
            {
              "depth": 3,
              "value": "globalThis",
              "heading": "globalthis"
            },
            {
              "depth": 2,
              "value": "函数属性",
              "heading": "函数属性"
            },
            {
              "depth": 3,
              "value": "eval()",
              "heading": "eval"
            },
            {
              "depth": 3,
              "value": "isNaN()",
              "heading": "isnan"
            },
            {
              "depth": 3,
              "value": "parseFloat()",
              "heading": "parsefloat"
            },
            {
              "depth": 3,
              "value": "parseInt(string, radix)",
              "heading": "parseintstring-radix"
            },
            {
              "depth": 3,
              "value": "decodeURI()",
              "heading": "decodeuri"
            },
            {
              "depth": 3,
              "value": "encodeURI()",
              "heading": "encodeuri"
            },
            {
              "depth": 3,
              "value": "decodeURIComponent",
              "heading": "decodeuricomponent"
            },
            {
              "depth": 3,
              "value": "encodeURIComponent",
              "heading": "encodeuricomponent"
            },
            {
              "depth": 2,
              "value": "基本对象",
              "heading": "基本对象"
            },
            {
              "depth": 2,
              "value": "Object",
              "heading": "object"
            },
            {
              "depth": 3,
              "value": "常用",
              "heading": "常用"
            },
            {
              "depth": 3,
              "value": "Object.create",
              "heading": "objectcreate"
            },
            {
              "depth": 3,
              "value": "Object.assign",
              "heading": "objectassign"
            },
            {
              "depth": 3,
              "value": "Object.keys",
              "heading": "objectkeys"
            },
            {
              "depth": 3,
              "value": "Object.values",
              "heading": "objectvalues"
            },
            {
              "depth": 3,
              "value": "Object.toString",
              "heading": "objecttostring"
            },
            {
              "depth": 3,
              "value": "Object.prototype.toLocaleString",
              "heading": "objectprototypetolocalestring"
            },
            {
              "depth": 3,
              "value": "Object.prototype.valueOf",
              "heading": "objectprototypevalueof"
            },
            {
              "depth": 3,
              "value": "Object.entries",
              "heading": "objectentries"
            },
            {
              "depth": 3,
              "value": "Object.fromEntries",
              "heading": "objectfromentries"
            },
            {
              "depth": 3,
              "value": "Object.is",
              "heading": "objectis"
            },
            {
              "depth": 3,
              "value": "Object.hasOwn",
              "heading": "objecthasown"
            },
            {
              "depth": 3,
              "value": "Object.prototype.hasOwnProperty",
              "heading": "objectprototypehasownproperty"
            },
            {
              "depth": 3,
              "value": "Object.prototype.isPrototypeOf",
              "heading": "objectprototypeisprototypeof"
            },
            {
              "depth": 3,
              "value": "",
              "heading": ""
            },
            {
              "depth": 3,
              "value": "不常用",
              "heading": "不常用"
            },
            {
              "depth": 3,
              "value": "Object.freeze",
              "heading": "objectfreeze"
            },
            {
              "depth": 3,
              "value": "Object.isFrozen",
              "heading": "objectisfrozen"
            },
            {
              "depth": 3,
              "value": "Object.seal",
              "heading": "objectseal"
            },
            {
              "depth": 3,
              "value": "Object.isSealed",
              "heading": "objectissealed"
            },
            {
              "depth": 3,
              "value": "Object.preventExtensions",
              "heading": "objectpreventextensions"
            },
            {
              "depth": 3,
              "value": "Object.isExtensible",
              "heading": "objectisextensible"
            },
            {
              "depth": 3,
              "value": "Object.getOwnPropertyDescriptor",
              "heading": "objectgetownpropertydescriptor"
            },
            {
              "depth": 3,
              "value": "Object.getOwnPropertyDescriptors",
              "heading": "objectgetownpropertydescriptors"
            },
            {
              "depth": 3,
              "value": "Object.getPrototypeOf",
              "heading": "objectgetprototypeof"
            },
            {
              "depth": 3,
              "value": "Object.getOwnPropertyNames",
              "heading": "objectgetownpropertynames"
            },
            {
              "depth": 3,
              "value": "Object.getOwnPropertySymbols",
              "heading": "objectgetownpropertysymbols"
            },
            {
              "depth": 3,
              "value": "Object.prototype.propertyIsEnumerable",
              "heading": "objectprototypepropertyisenumerable"
            },
            {
              "depth": 3,
              "value": "Object.defineProperty",
              "heading": "objectdefineproperty"
            },
            {
              "depth": 3,
              "value": "Object.defineProperties",
              "heading": "objectdefineproperties"
            },
            {
              "depth": 3,
              "value": "",
              "heading": "-1"
            },
            {
              "depth": 2,
              "value": "Function",
              "heading": "function"
            },
            {
              "depth": 3,
              "value": "属性",
              "heading": "属性"
            },
            {
              "depth": 5,
              "value": "Function.prototype.length",
              "heading": "functionprototypelength"
            },
            {
              "depth": 5,
              "value": "Function.prototype.name",
              "heading": "functionprototypename"
            },
            {
              "depth": 3,
              "value": "方法",
              "heading": "方法"
            },
            {
              "depth": 4,
              "value": "Function.prototype.apply",
              "heading": "functionprototypeapply"
            },
            {
              "depth": 4,
              "value": "Function.prototype.call",
              "heading": "functionprototypecall"
            },
            {
              "depth": 4,
              "value": "Function.prototype.bind",
              "heading": "functionprototypebind"
            },
            {
              "depth": 4,
              "value": "Function.prototype.toString",
              "heading": "functionprototypetostring"
            },
            {
              "depth": 2,
              "value": "Math",
              "heading": "math"
            },
            {
              "depth": 2,
              "value": "Date",
              "heading": "date"
            },
            {
              "depth": 2,
              "value": "String",
              "heading": "string"
            },
            {
              "depth": 2,
              "value": "RegExp",
              "heading": "regexp"
            },
            {
              "depth": 3,
              "value": "属性",
              "heading": "属性-1"
            },
            {
              "depth": 4,
              "value": "lastIndex",
              "heading": "lastindex"
            },
            {
              "depth": 3,
              "value": "实例方法",
              "heading": "实例方法"
            },
            {
              "depth": 4,
              "value": "test",
              "heading": "test"
            },
            {
              "depth": 4,
              "value": "exec",
              "heading": "exec"
            },
            {
              "depth": 3,
              "value": "修饰符",
              "heading": "修饰符"
            },
            {
              "depth": 3,
              "value": "元字符",
              "heading": "元字符"
            },
            {
              "depth": 3,
              "value": "正则表达式 - 运算符优先级",
              "heading": "正则表达式---运算符优先级"
            },
            {
              "depth": 4,
              "value": "贪婪模式",
              "heading": "贪婪模式"
            },
            {
              "depth": 2,
              "value": "Array",
              "heading": "array"
            },
            {
              "depth": 3,
              "value": "属性",
              "heading": "属性-2"
            },
            {
              "depth": 4,
              "value": "length",
              "heading": "length"
            },
            {
              "depth": 3,
              "value": "方法",
              "heading": "方法-1"
            },
            {
              "depth": 4,
              "value": "from",
              "heading": "from"
            },
            {
              "depth": 4,
              "value": "isArray",
              "heading": "isarray"
            },
            {
              "depth": 4,
              "value": "of",
              "heading": "of"
            },
            {
              "depth": 3,
              "value": "实例方法",
              "heading": "实例方法-1"
            },
            {
              "depth": 4,
              "value": "at",
              "heading": "at"
            },
            {
              "depth": 4,
              "value": "concat",
              "heading": "concat"
            },
            {
              "depth": 4,
              "value": "entries",
              "heading": "entries"
            },
            {
              "depth": 4,
              "value": "fill",
              "heading": "fill"
            },
            {
              "depth": 4,
              "value": "every",
              "heading": "every"
            },
            {
              "depth": 4,
              "value": "some",
              "heading": "some"
            },
            {
              "depth": 4,
              "value": "filter",
              "heading": "filter"
            },
            {
              "depth": 4,
              "value": "find",
              "heading": "find"
            },
            {
              "depth": 4,
              "value": "findIndex",
              "heading": "findindex"
            },
            {
              "depth": 4,
              "value": "findLast",
              "heading": "findlast"
            },
            {
              "depth": 4,
              "value": "findIndexLast",
              "heading": "findindexlast"
            },
            {
              "depth": 4,
              "value": "flat",
              "heading": "flat"
            },
            {
              "depth": 4,
              "value": "flatMap",
              "heading": "flatmap"
            },
            {
              "depth": 4,
              "value": "map",
              "heading": "map"
            },
            {
              "depth": 4,
              "value": "forEach",
              "heading": "foreach"
            },
            {
              "depth": 4,
              "value": "includes",
              "heading": "includes"
            },
            {
              "depth": 4,
              "value": "indexOf",
              "heading": "indexof"
            },
            {
              "depth": 4,
              "value": "lastIndexOf",
              "heading": "lastindexof"
            },
            {
              "depth": 4,
              "value": "join",
              "heading": "join"
            },
            {
              "depth": 4,
              "value": "keys",
              "heading": "keys"
            },
            {
              "depth": 4,
              "value": "values",
              "heading": "values"
            },
            {
              "depth": 4,
              "value": "pop",
              "heading": "pop"
            },
            {
              "depth": 4,
              "value": "shift",
              "heading": "shift"
            },
            {
              "depth": 4,
              "value": "unshift",
              "heading": "unshift"
            },
            {
              "depth": 4,
              "value": "push",
              "heading": "push"
            },
            {
              "depth": 4,
              "value": "reduce",
              "heading": "reduce"
            },
            {
              "depth": 4,
              "value": "reduceRight",
              "heading": "reduceright"
            },
            {
              "depth": 4,
              "value": "reverse",
              "heading": "reverse"
            },
            {
              "depth": 4,
              "value": "sort",
              "heading": "sort"
            },
            {
              "depth": 4,
              "value": "splice",
              "heading": "splice"
            },
            {
              "depth": 2,
              "value": "Map",
              "heading": "map-1"
            },
            {
              "depth": 2,
              "value": "Set",
              "heading": "set"
            },
            {
              "depth": 2,
              "value": "Map 与 Set Api",
              "heading": "map-与-set-api"
            },
            {
              "depth": 2,
              "value": "WeakMap",
              "heading": "weakmap"
            },
            {
              "depth": 3,
              "value": "set",
              "heading": "set-1"
            },
            {
              "depth": 3,
              "value": "get",
              "heading": "get"
            },
            {
              "depth": 3,
              "value": "delete",
              "heading": "delete"
            },
            {
              "depth": 3,
              "value": "has",
              "heading": "has"
            },
            {
              "depth": 2,
              "value": "WeakSet",
              "heading": "weakset"
            },
            {
              "depth": 3,
              "value": "add",
              "heading": "add"
            },
            {
              "depth": 3,
              "value": "delete",
              "heading": "delete-1"
            },
            {
              "depth": 3,
              "value": "has",
              "heading": "has-1"
            },
            {
              "depth": 2,
              "value": "Reflect",
              "heading": "reflect"
            },
            {
              "depth": 2,
              "value": "Proxy",
              "heading": "proxy"
            },
            {
              "depth": 3,
              "value": "Proxy.revocable",
              "heading": "proxyrevocable"
            },
            {
              "depth": 3,
              "value": "handler",
              "heading": "handler"
            },
            {
              "depth": 4,
              "value": "set",
              "heading": "set-2"
            },
            {
              "depth": 4,
              "value": "get",
              "heading": "get-1"
            },
            {
              "depth": 4,
              "value": "has",
              "heading": "has-2"
            },
            {
              "depth": 4,
              "value": "construct",
              "heading": "construct"
            },
            {
              "depth": 4,
              "value": "apply",
              "heading": "apply"
            },
            {
              "depth": 4,
              "value": "deleteProperty",
              "heading": "deleteproperty"
            }
          ],
          "title": "内置对象",
          "nav": {
            "path": "/guide",
            "title": "前端之路"
          },
          "group": {
            "path": "/guide/基础知识js",
            "title": "基础知识js"
          }
        },
        "title": "内置对象 - 知识海洋里的淡水鱼"
      },
      {
        "path": "/guide/好用的网站/好用的网站",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'docs__guide__好用的网站__好用的网站.md' */'F:/LYH_work/mycode/my-markdown/docs/guide/好用的网站/好用的网站.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "docs/guide/好用的网站/好用的网站.md",
          "updatedTime": 1664182360000,
          "slugs": [
            {
              "depth": 1,
              "value": "这是前端开发比较有用的网站",
              "heading": "这是前端开发比较有用的网站"
            },
            {
              "depth": 2,
              "value": "提升开发速度好用",
              "heading": "提升开发速度好用"
            }
          ],
          "title": "这是前端开发比较有用的网站",
          "nav": {
            "path": "/guide",
            "title": "前端之路"
          },
          "group": {
            "path": "/guide/好用的网站",
            "title": "好用的网站"
          }
        },
        "title": "这是前端开发比较有用的网站 - 知识海洋里的淡水鱼"
      },
      {
        "path": "/guide/我的type-script相关代码",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'docs__guide__我的TypeScript相关代码__index.md' */'F:/LYH_work/mycode/my-markdown/docs/guide/我的TypeScript相关代码/index.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "docs/guide/我的TypeScript相关代码/index.md",
          "updatedTime": 1663839587000,
          "title": "我的TypeScript相关代码",
          "order": 1,
          "nav": {
            "title": "前端之路",
            "order": 1,
            "path": "/guide"
          },
          "slugs": [
            {
              "depth": 1,
              "value": "我的 TypeScript 相关代码",
              "heading": "我的-typescript-相关代码"
            },
            {
              "depth": 2,
              "value": "enum",
              "heading": "enum"
            },
            {
              "depth": 2,
              "value": "infer",
              "heading": "infer"
            },
            {
              "depth": 2,
              "value": "索引访问类型",
              "heading": "索引访问类型"
            },
            {
              "depth": 2,
              "value": "映射类型",
              "heading": "映射类型"
            },
            {
              "depth": 2,
              "value": "模板字面量类型",
              "heading": "模板字面量类型"
            },
            {
              "depth": 2,
              "value": "内置字符操作类型",
              "heading": "内置字符操作类型"
            },
            {
              "depth": 2,
              "value": "Utility Types",
              "heading": "utility-types"
            },
            {
              "depth": 3,
              "value": "Awaited<Type>",
              "heading": "awaitedtype"
            },
            {
              "depth": 3,
              "value": "Partial<Type>",
              "heading": "partialtype"
            },
            {
              "depth": 3,
              "value": "Required<Type>",
              "heading": "requiredtype"
            },
            {
              "depth": 3,
              "value": "Readonly<Type>",
              "heading": "readonlytype"
            },
            {
              "depth": 3,
              "value": "Record<Keys, Type>",
              "heading": "recordkeys-type"
            },
            {
              "depth": 3,
              "value": "Pick<Type, Keys>",
              "heading": "picktype-keys"
            },
            {
              "depth": 3,
              "value": "Omit<Type, Keys>",
              "heading": "omittype-keys"
            },
            {
              "depth": 3,
              "value": "Exclude<UnionType, ExcludedMembers>",
              "heading": "excludeuniontype-excludedmembers"
            },
            {
              "depth": 3,
              "value": "Extract<Type, Union>",
              "heading": "extracttype-union"
            },
            {
              "depth": 3,
              "value": "NonNullable<Type>",
              "heading": "nonnullabletype"
            },
            {
              "depth": 3,
              "value": "Parameters<Type>",
              "heading": "parameterstype"
            },
            {
              "depth": 3,
              "value": "ConstructorParameters<Type>",
              "heading": "constructorparameterstype"
            },
            {
              "depth": 3,
              "value": "ReturnType<Type>",
              "heading": "returntypetype"
            },
            {
              "depth": 3,
              "value": "InstanceType<Type>",
              "heading": "instancetypetype"
            },
            {
              "depth": 3,
              "value": "ThisParameterType<Type>",
              "heading": "thisparametertypetype"
            },
            {
              "depth": 3,
              "value": "OmitThisParameter<Type>",
              "heading": "omitthisparametertype"
            },
            {
              "depth": 3,
              "value": "ThisType<Type>",
              "heading": "thistypetype"
            },
            {
              "depth": 2,
              "value": "我的工具函数",
              "heading": "我的工具函数"
            },
            {
              "depth": 3,
              "value": "OverrideProperty",
              "heading": "overrideproperty"
            },
            {
              "depth": 3,
              "value": "DeepPartial",
              "heading": "deeppartial"
            },
            {
              "depth": 3,
              "value": "DeepRequired",
              "heading": "deeprequired"
            },
            {
              "depth": 3,
              "value": "GetCommonKeys",
              "heading": "getcommonkeys"
            },
            {
              "depth": 3,
              "value": "DeletePartial",
              "heading": "deletepartial"
            },
            {
              "depth": 3,
              "value": "差集",
              "heading": "差集"
            },
            {
              "depth": 3,
              "value": "tuple => union",
              "heading": "tuple--union"
            },
            {
              "depth": 3,
              "value": "union => intersection",
              "heading": "union--intersection"
            },
            {
              "depth": 2,
              "value": "操作符",
              "heading": "操作符"
            },
            {
              "depth": 2,
              "value": "type 与 interface 的区别",
              "heading": "type-与-interface-的区别"
            },
            {
              "depth": 2,
              "value": "提取函数类型",
              "heading": "提取函数类型"
            },
            {
              "depth": 2,
              "value": "dispath 转换",
              "heading": "dispath-转换"
            },
            {
              "depth": 2,
              "value": "混合继承",
              "heading": "混合继承"
            },
            {
              "depth": 2,
              "value": "React 与 TypeScript",
              "heading": "react-与-typescript"
            },
            {
              "depth": 3,
              "value": "TypeScript 获取 react 及 vue 组件实例",
              "heading": "typescript-获取-react-及-vue-组件实例"
            },
            {
              "depth": 4,
              "value": "class 获取组件实例",
              "heading": "class-获取组件实例"
            },
            {
              "depth": 4,
              "value": "hook 获取 ref - 1",
              "heading": "hook-获取-ref---1"
            },
            {
              "depth": 4,
              "value": "hook 获取 ref - 2",
              "heading": "hook-获取-ref---2"
            },
            {
              "depth": 4,
              "value": "vue3",
              "heading": "vue3"
            },
            {
              "depth": 2,
              "value": "报错的解决",
              "heading": "报错的解决"
            },
            {
              "depth": 3,
              "value": "元组",
              "heading": "元组"
            },
            {
              "depth": 3,
              "value": "对象索引形式",
              "heading": "对象索引形式"
            },
            {
              "depth": 3,
              "value": "对象尚未定义",
              "heading": "对象尚未定义"
            }
          ],
          "group": {
            "path": "/guide/我的type-script相关代码",
            "title": "我的TypeScript相关代码"
          }
        },
        "title": "我的TypeScript相关代码 - 知识海洋里的淡水鱼"
      },
      {
        "path": "/guide/未整理",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'docs__guide__未整理__index.md' */'F:/LYH_work/mycode/my-markdown/docs/guide/未整理/index.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "docs/guide/未整理/index.md",
          "updatedTime": 1663839587000,
          "title": "未整理",
          "order": 1,
          "nav": {
            "title": "前端之路",
            "order": 1,
            "path": "/guide"
          },
          "slugs": [
            {
              "depth": 1,
              "value": "未整理",
              "heading": "未整理"
            },
            {
              "depth": 2,
              "value": "React",
              "heading": "react"
            },
            {
              "depth": 2,
              "value": "Vue",
              "heading": "vue"
            },
            {
              "depth": 2,
              "value": "js",
              "heading": "js"
            },
            {
              "depth": 2,
              "value": "gis",
              "heading": "gis"
            },
            {
              "depth": 3,
              "value": "地图遇到数据不显示时",
              "heading": "地图遇到数据不显示时"
            },
            {
              "depth": 2,
              "value": "其他",
              "heading": "其他"
            },
            {
              "depth": 2,
              "value": "可视化入门",
              "heading": "可视化入门"
            },
            {
              "depth": 3,
              "value": "canvas 教程",
              "heading": "canvas-教程"
            },
            {
              "depth": 3,
              "value": "svg 教程",
              "heading": "svg-教程"
            },
            {
              "depth": 3,
              "value": "d3 教程",
              "heading": "d3-教程"
            },
            {
              "depth": 3,
              "value": "webGL",
              "heading": "webgl"
            },
            {
              "depth": 3,
              "value": "threejs",
              "heading": "threejs"
            },
            {
              "depth": 3,
              "value": "工具",
              "heading": "工具"
            },
            {
              "depth": 3,
              "value": "其他链接",
              "heading": "其他链接"
            }
          ],
          "group": {
            "path": "/guide/未整理",
            "title": "未整理"
          }
        },
        "title": "未整理 - 知识海洋里的淡水鱼"
      },
      {
        "path": "/guide/高级前端必读",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'docs__guide__高级前端必读__index.md' */'F:/LYH_work/mycode/my-markdown/docs/guide/高级前端必读/index.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "docs/guide/高级前端必读/index.md",
          "updatedTime": 1663839587000,
          "title": "高级前端必读",
          "order": 1,
          "nav": {
            "title": "前端之路",
            "order": 1,
            "path": "/guide"
          },
          "slugs": [
            {
              "depth": 2,
              "value": "高级前端必读",
              "heading": "高级前端必读"
            }
          ],
          "group": {
            "path": "/guide/高级前端必读",
            "title": "高级前端必读"
          }
        },
        "title": "高级前端必读 - 知识海洋里的淡水鱼"
      },
      {
        "path": "/map",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'docs__map__index.md' */'F:/LYH_work/mycode/my-markdown/docs/map/index.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "docs/map/index.md",
          "updatedTime": 1668592556000,
          "title": "总览",
          "nav": {
            "path": "/map",
            "title": "地图",
            "order": 2
          },
          "slugs": [
            {
              "depth": 1,
              "value": "gis",
              "heading": "gis"
            },
            {
              "depth": 1,
              "value": "常用的前端地图框架（WebGIS 框架）",
              "heading": "常用的前端地图框架webgis-框架"
            },
            {
              "depth": 3,
              "value": "Leaflet",
              "heading": "leaflet"
            },
            {
              "depth": 3,
              "value": "Mapbox GL JS",
              "heading": "mapbox-gl-js"
            },
            {
              "depth": 3,
              "value": "ArcGIS API for JS",
              "heading": "arcgis-api-for-js"
            },
            {
              "depth": 3,
              "value": "Openlayers",
              "heading": "openlayers"
            },
            {
              "depth": 3,
              "value": "Cesium",
              "heading": "cesium"
            },
            {
              "depth": 3,
              "value": "百度地图 JS API /百度地图 API GL",
              "heading": "百度地图-js-api-百度地图-api-gl"
            },
            {
              "depth": 3,
              "value": "高德地图 JS API",
              "heading": "高德地图-js-api"
            },
            {
              "depth": 3,
              "value": "Google Maps JS API",
              "heading": "google-maps-js-api"
            },
            {
              "depth": 3,
              "value": "AntV L7",
              "heading": "antv-l7"
            },
            {
              "depth": 1,
              "value": "在线地图服务的 url",
              "heading": "在线地图服务的-url"
            },
            {
              "depth": 2,
              "value": "　　上面的、、 这些表示该区间内的数值，任取一个即可。（在 openlayers 里面加载直接这样写可以，在 QGIS 里需要取一个值）",
              "heading": "上面的-这些表示该区间内的数值任取一个即可在-openlayers-里面加载直接这样写可以在-qgis-里需要取一个值"
            }
          ]
        },
        "title": "总览 - 知识海洋里的淡水鱼"
      },
      {
        "path": "/map/leaflet",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'docs__map__Leaflet__index.md' */'F:/LYH_work/mycode/my-markdown/docs/map/Leaflet/index.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "docs/map/Leaflet/index.md",
          "updatedTime": 1668592556000,
          "slugs": [
            {
              "depth": 1,
              "value": "快速开始",
              "heading": "快速开始"
            },
            {
              "depth": 3,
              "value": "初始化一个带有图层的地图",
              "heading": "初始化一个带有图层的地图"
            }
          ],
          "title": "快速开始",
          "hasPreviewer": true,
          "nav": {
            "path": "/map",
            "title": "地图"
          },
          "group": {
            "path": "/map/leaflet",
            "title": "Leaflet"
          }
        },
        "title": "快速开始 - 知识海洋里的淡水鱼"
      },
      {
        "path": "/mapbox",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'docs__map__Mapbox__index.md' */'F:/LYH_work/mycode/my-markdown/docs/map/Mapbox/index.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "docs/map/Mapbox/index.md",
          "updatedTime": 1668592556000,
          "slugs": [
            {
              "depth": 1,
              "value": "Mapbox",
              "heading": "mapbox"
            },
            {
              "depth": 1,
              "value": "分屏展示 Demo",
              "heading": "分屏展示-demo"
            }
          ],
          "title": "Mapbox",
          "hasPreviewer": true,
          "nav": {
            "path": "/map",
            "title": "地图"
          },
          "group": {
            "path": "/mapbox",
            "title": "Mapbox"
          }
        },
        "title": "Mapbox - 知识海洋里的淡水鱼"
      },
      {
        "path": "/zh-CN/components/AutoScrollList/auto-scroll-list",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'Components__AutoScrollList__index.md' */'F:/LYH_work/mycode/my-markdown/src/Components/AutoScrollList/index.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "src/Components/AutoScrollList/index.md",
          "updatedTime": 1669704228376,
          "componentName": "AutoScrollList",
          "nav": {
            "path": "/zh-CN/components",
            "title": "Components"
          },
          "group": {
            "path": "/zh-CN/components/AutoScrollList",
            "title": "AutoScrollList"
          },
          "slugs": [
            {
              "depth": 1,
              "value": "AutoScrollList",
              "heading": "autoscrolllist"
            }
          ],
          "title": "AutoScrollList",
          "hasPreviewer": true,
          "locale": "zh-CN"
        },
        "title": "AutoScrollList - 知识海洋里的淡水鱼"
      },
      {
        "path": "/zh-CN/guide",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'docs__guide__index.md' */'F:/LYH_work/mycode/my-markdown/docs/guide/index.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "docs/guide/index.md",
          "updatedTime": 1663839587000,
          "title": "总览",
          "order": 1,
          "nav": {
            "title": "前端之路",
            "order": 1,
            "path": "/zh-CN/guide"
          },
          "slugs": [
            {
              "depth": 2,
              "value": "1. 2022-plan",
              "heading": "1-2022-plan"
            },
            {
              "depth": 2,
              "value": "2. 需要掌握的基本规范",
              "heading": "2-需要掌握的基本规范"
            },
            {
              "depth": 2,
              "value": "3. CSS",
              "heading": "3-css"
            },
            {
              "depth": 2,
              "value": "4.写文档的工具",
              "heading": "4写文档的工具"
            },
            {
              "depth": 2,
              "value": "5. 前端工程化",
              "heading": "5-前端工程化"
            },
            {
              "depth": 2,
              "value": "6. 运维相关",
              "heading": "6-运维相关"
            },
            {
              "depth": 2,
              "value": "7. 单元测试",
              "heading": "7-单元测试"
            },
            {
              "depth": 2,
              "value": "8. 实践操作",
              "heading": "8-实践操作"
            },
            {
              "depth": 2,
              "value": "9. react 及周边",
              "heading": "9-react-及周边"
            },
            {
              "depth": 2,
              "value": "10. vue 及周边",
              "heading": "10-vue-及周边"
            },
            {
              "depth": 2,
              "value": "11. 微信小程序",
              "heading": "11-微信小程序"
            },
            {
              "depth": 2,
              "value": "12. typescript",
              "heading": "12-typescript"
            },
            {
              "depth": 2,
              "value": "13. 源码",
              "heading": "13-源码"
            },
            {
              "depth": 2,
              "value": "14. 可视化",
              "heading": "14-可视化"
            },
            {
              "depth": 2,
              "value": "15. gis",
              "heading": "15-gis"
            },
            {
              "depth": 2,
              "value": "16. 前端的其他 API",
              "heading": "16-前端的其他-api"
            },
            {
              "depth": 2,
              "value": "17. 项目难点",
              "heading": "17-项目难点"
            },
            {
              "depth": 2,
              "value": "18. 设计模式",
              "heading": "18-设计模式"
            },
            {
              "depth": 2,
              "value": "19. 算法",
              "heading": "19-算法"
            },
            {
              "depth": 2,
              "value": "20. 有意思的库",
              "heading": "20-有意思的库"
            },
            {
              "depth": 2,
              "value": "21.macos 相关",
              "heading": "21macos-相关"
            }
          ],
          "locale": "zh-CN"
        },
        "title": "总览 - 知识海洋里的淡水鱼"
      },
      {
        "path": "/zh-CN/guide/type-script进阶文章",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'docs__guide__TypeScript进阶文章__index.md' */'F:/LYH_work/mycode/my-markdown/docs/guide/TypeScript进阶文章/index.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "docs/guide/TypeScript进阶文章/index.md",
          "updatedTime": 1663839587000,
          "title": "TypeScript进阶文章",
          "order": 1,
          "nav": {
            "title": "前端之路",
            "order": 1,
            "path": "/zh-CN/guide"
          },
          "slugs": [
            {
              "depth": 2,
              "value": "TypeScript 进阶文章",
              "heading": "typescript-进阶文章"
            },
            {
              "depth": 2,
              "value": "其他文档",
              "heading": "其他文档"
            }
          ],
          "group": {
            "path": "/zh-CN/guide/type-script进阶文章",
            "title": "TypeScript进阶文章"
          },
          "locale": "zh-CN"
        },
        "title": "TypeScript进阶文章 - 知识海洋里的淡水鱼"
      },
      {
        "path": "/zh-CN/guide/基础知识js/内置对象",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'docs__guide__基础知识js__内置对象.md' */'F:/LYH_work/mycode/my-markdown/docs/guide/基础知识js/内置对象.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "docs/guide/基础知识js/内置对象.md",
          "updatedTime": 1668592556000,
          "slugs": [
            {
              "depth": 1,
              "value": "内置对象",
              "heading": "内置对象"
            },
            {
              "depth": 2,
              "value": "值属性",
              "heading": "值属性"
            },
            {
              "depth": 3,
              "value": "Infinity",
              "heading": "infinity"
            },
            {
              "depth": 3,
              "value": "NaN",
              "heading": "nan"
            },
            {
              "depth": 3,
              "value": "undefined",
              "heading": "undefined"
            },
            {
              "depth": 3,
              "value": "globalThis",
              "heading": "globalthis"
            },
            {
              "depth": 2,
              "value": "函数属性",
              "heading": "函数属性"
            },
            {
              "depth": 3,
              "value": "eval()",
              "heading": "eval"
            },
            {
              "depth": 3,
              "value": "isNaN()",
              "heading": "isnan"
            },
            {
              "depth": 3,
              "value": "parseFloat()",
              "heading": "parsefloat"
            },
            {
              "depth": 3,
              "value": "parseInt(string, radix)",
              "heading": "parseintstring-radix"
            },
            {
              "depth": 3,
              "value": "decodeURI()",
              "heading": "decodeuri"
            },
            {
              "depth": 3,
              "value": "encodeURI()",
              "heading": "encodeuri"
            },
            {
              "depth": 3,
              "value": "decodeURIComponent",
              "heading": "decodeuricomponent"
            },
            {
              "depth": 3,
              "value": "encodeURIComponent",
              "heading": "encodeuricomponent"
            },
            {
              "depth": 2,
              "value": "基本对象",
              "heading": "基本对象"
            },
            {
              "depth": 2,
              "value": "Object",
              "heading": "object"
            },
            {
              "depth": 3,
              "value": "常用",
              "heading": "常用"
            },
            {
              "depth": 3,
              "value": "Object.create",
              "heading": "objectcreate"
            },
            {
              "depth": 3,
              "value": "Object.assign",
              "heading": "objectassign"
            },
            {
              "depth": 3,
              "value": "Object.keys",
              "heading": "objectkeys"
            },
            {
              "depth": 3,
              "value": "Object.values",
              "heading": "objectvalues"
            },
            {
              "depth": 3,
              "value": "Object.toString",
              "heading": "objecttostring"
            },
            {
              "depth": 3,
              "value": "Object.prototype.toLocaleString",
              "heading": "objectprototypetolocalestring"
            },
            {
              "depth": 3,
              "value": "Object.prototype.valueOf",
              "heading": "objectprototypevalueof"
            },
            {
              "depth": 3,
              "value": "Object.entries",
              "heading": "objectentries"
            },
            {
              "depth": 3,
              "value": "Object.fromEntries",
              "heading": "objectfromentries"
            },
            {
              "depth": 3,
              "value": "Object.is",
              "heading": "objectis"
            },
            {
              "depth": 3,
              "value": "Object.hasOwn",
              "heading": "objecthasown"
            },
            {
              "depth": 3,
              "value": "Object.prototype.hasOwnProperty",
              "heading": "objectprototypehasownproperty"
            },
            {
              "depth": 3,
              "value": "Object.prototype.isPrototypeOf",
              "heading": "objectprototypeisprototypeof"
            },
            {
              "depth": 3,
              "value": "",
              "heading": ""
            },
            {
              "depth": 3,
              "value": "不常用",
              "heading": "不常用"
            },
            {
              "depth": 3,
              "value": "Object.freeze",
              "heading": "objectfreeze"
            },
            {
              "depth": 3,
              "value": "Object.isFrozen",
              "heading": "objectisfrozen"
            },
            {
              "depth": 3,
              "value": "Object.seal",
              "heading": "objectseal"
            },
            {
              "depth": 3,
              "value": "Object.isSealed",
              "heading": "objectissealed"
            },
            {
              "depth": 3,
              "value": "Object.preventExtensions",
              "heading": "objectpreventextensions"
            },
            {
              "depth": 3,
              "value": "Object.isExtensible",
              "heading": "objectisextensible"
            },
            {
              "depth": 3,
              "value": "Object.getOwnPropertyDescriptor",
              "heading": "objectgetownpropertydescriptor"
            },
            {
              "depth": 3,
              "value": "Object.getOwnPropertyDescriptors",
              "heading": "objectgetownpropertydescriptors"
            },
            {
              "depth": 3,
              "value": "Object.getPrototypeOf",
              "heading": "objectgetprototypeof"
            },
            {
              "depth": 3,
              "value": "Object.getOwnPropertyNames",
              "heading": "objectgetownpropertynames"
            },
            {
              "depth": 3,
              "value": "Object.getOwnPropertySymbols",
              "heading": "objectgetownpropertysymbols"
            },
            {
              "depth": 3,
              "value": "Object.prototype.propertyIsEnumerable",
              "heading": "objectprototypepropertyisenumerable"
            },
            {
              "depth": 3,
              "value": "Object.defineProperty",
              "heading": "objectdefineproperty"
            },
            {
              "depth": 3,
              "value": "Object.defineProperties",
              "heading": "objectdefineproperties"
            },
            {
              "depth": 3,
              "value": "",
              "heading": "-1"
            },
            {
              "depth": 2,
              "value": "Function",
              "heading": "function"
            },
            {
              "depth": 3,
              "value": "属性",
              "heading": "属性"
            },
            {
              "depth": 5,
              "value": "Function.prototype.length",
              "heading": "functionprototypelength"
            },
            {
              "depth": 5,
              "value": "Function.prototype.name",
              "heading": "functionprototypename"
            },
            {
              "depth": 3,
              "value": "方法",
              "heading": "方法"
            },
            {
              "depth": 4,
              "value": "Function.prototype.apply",
              "heading": "functionprototypeapply"
            },
            {
              "depth": 4,
              "value": "Function.prototype.call",
              "heading": "functionprototypecall"
            },
            {
              "depth": 4,
              "value": "Function.prototype.bind",
              "heading": "functionprototypebind"
            },
            {
              "depth": 4,
              "value": "Function.prototype.toString",
              "heading": "functionprototypetostring"
            },
            {
              "depth": 2,
              "value": "Math",
              "heading": "math"
            },
            {
              "depth": 2,
              "value": "Date",
              "heading": "date"
            },
            {
              "depth": 2,
              "value": "String",
              "heading": "string"
            },
            {
              "depth": 2,
              "value": "RegExp",
              "heading": "regexp"
            },
            {
              "depth": 3,
              "value": "属性",
              "heading": "属性-1"
            },
            {
              "depth": 4,
              "value": "lastIndex",
              "heading": "lastindex"
            },
            {
              "depth": 3,
              "value": "实例方法",
              "heading": "实例方法"
            },
            {
              "depth": 4,
              "value": "test",
              "heading": "test"
            },
            {
              "depth": 4,
              "value": "exec",
              "heading": "exec"
            },
            {
              "depth": 3,
              "value": "修饰符",
              "heading": "修饰符"
            },
            {
              "depth": 3,
              "value": "元字符",
              "heading": "元字符"
            },
            {
              "depth": 3,
              "value": "正则表达式 - 运算符优先级",
              "heading": "正则表达式---运算符优先级"
            },
            {
              "depth": 4,
              "value": "贪婪模式",
              "heading": "贪婪模式"
            },
            {
              "depth": 2,
              "value": "Array",
              "heading": "array"
            },
            {
              "depth": 3,
              "value": "属性",
              "heading": "属性-2"
            },
            {
              "depth": 4,
              "value": "length",
              "heading": "length"
            },
            {
              "depth": 3,
              "value": "方法",
              "heading": "方法-1"
            },
            {
              "depth": 4,
              "value": "from",
              "heading": "from"
            },
            {
              "depth": 4,
              "value": "isArray",
              "heading": "isarray"
            },
            {
              "depth": 4,
              "value": "of",
              "heading": "of"
            },
            {
              "depth": 3,
              "value": "实例方法",
              "heading": "实例方法-1"
            },
            {
              "depth": 4,
              "value": "at",
              "heading": "at"
            },
            {
              "depth": 4,
              "value": "concat",
              "heading": "concat"
            },
            {
              "depth": 4,
              "value": "entries",
              "heading": "entries"
            },
            {
              "depth": 4,
              "value": "fill",
              "heading": "fill"
            },
            {
              "depth": 4,
              "value": "every",
              "heading": "every"
            },
            {
              "depth": 4,
              "value": "some",
              "heading": "some"
            },
            {
              "depth": 4,
              "value": "filter",
              "heading": "filter"
            },
            {
              "depth": 4,
              "value": "find",
              "heading": "find"
            },
            {
              "depth": 4,
              "value": "findIndex",
              "heading": "findindex"
            },
            {
              "depth": 4,
              "value": "findLast",
              "heading": "findlast"
            },
            {
              "depth": 4,
              "value": "findIndexLast",
              "heading": "findindexlast"
            },
            {
              "depth": 4,
              "value": "flat",
              "heading": "flat"
            },
            {
              "depth": 4,
              "value": "flatMap",
              "heading": "flatmap"
            },
            {
              "depth": 4,
              "value": "map",
              "heading": "map"
            },
            {
              "depth": 4,
              "value": "forEach",
              "heading": "foreach"
            },
            {
              "depth": 4,
              "value": "includes",
              "heading": "includes"
            },
            {
              "depth": 4,
              "value": "indexOf",
              "heading": "indexof"
            },
            {
              "depth": 4,
              "value": "lastIndexOf",
              "heading": "lastindexof"
            },
            {
              "depth": 4,
              "value": "join",
              "heading": "join"
            },
            {
              "depth": 4,
              "value": "keys",
              "heading": "keys"
            },
            {
              "depth": 4,
              "value": "values",
              "heading": "values"
            },
            {
              "depth": 4,
              "value": "pop",
              "heading": "pop"
            },
            {
              "depth": 4,
              "value": "shift",
              "heading": "shift"
            },
            {
              "depth": 4,
              "value": "unshift",
              "heading": "unshift"
            },
            {
              "depth": 4,
              "value": "push",
              "heading": "push"
            },
            {
              "depth": 4,
              "value": "reduce",
              "heading": "reduce"
            },
            {
              "depth": 4,
              "value": "reduceRight",
              "heading": "reduceright"
            },
            {
              "depth": 4,
              "value": "reverse",
              "heading": "reverse"
            },
            {
              "depth": 4,
              "value": "sort",
              "heading": "sort"
            },
            {
              "depth": 4,
              "value": "splice",
              "heading": "splice"
            },
            {
              "depth": 2,
              "value": "Map",
              "heading": "map-1"
            },
            {
              "depth": 2,
              "value": "Set",
              "heading": "set"
            },
            {
              "depth": 2,
              "value": "Map 与 Set Api",
              "heading": "map-与-set-api"
            },
            {
              "depth": 2,
              "value": "WeakMap",
              "heading": "weakmap"
            },
            {
              "depth": 3,
              "value": "set",
              "heading": "set-1"
            },
            {
              "depth": 3,
              "value": "get",
              "heading": "get"
            },
            {
              "depth": 3,
              "value": "delete",
              "heading": "delete"
            },
            {
              "depth": 3,
              "value": "has",
              "heading": "has"
            },
            {
              "depth": 2,
              "value": "WeakSet",
              "heading": "weakset"
            },
            {
              "depth": 3,
              "value": "add",
              "heading": "add"
            },
            {
              "depth": 3,
              "value": "delete",
              "heading": "delete-1"
            },
            {
              "depth": 3,
              "value": "has",
              "heading": "has-1"
            },
            {
              "depth": 2,
              "value": "Reflect",
              "heading": "reflect"
            },
            {
              "depth": 2,
              "value": "Proxy",
              "heading": "proxy"
            },
            {
              "depth": 3,
              "value": "Proxy.revocable",
              "heading": "proxyrevocable"
            },
            {
              "depth": 3,
              "value": "handler",
              "heading": "handler"
            },
            {
              "depth": 4,
              "value": "set",
              "heading": "set-2"
            },
            {
              "depth": 4,
              "value": "get",
              "heading": "get-1"
            },
            {
              "depth": 4,
              "value": "has",
              "heading": "has-2"
            },
            {
              "depth": 4,
              "value": "construct",
              "heading": "construct"
            },
            {
              "depth": 4,
              "value": "apply",
              "heading": "apply"
            },
            {
              "depth": 4,
              "value": "deleteProperty",
              "heading": "deleteproperty"
            }
          ],
          "title": "内置对象",
          "nav": {
            "path": "/zh-CN/guide",
            "title": "前端之路"
          },
          "group": {
            "path": "/zh-CN/guide/基础知识js",
            "title": "基础知识js"
          },
          "locale": "zh-CN"
        },
        "title": "内置对象 - 知识海洋里的淡水鱼"
      },
      {
        "path": "/zh-CN/guide/好用的网站/好用的网站",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'docs__guide__好用的网站__好用的网站.md' */'F:/LYH_work/mycode/my-markdown/docs/guide/好用的网站/好用的网站.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "docs/guide/好用的网站/好用的网站.md",
          "updatedTime": 1664182360000,
          "slugs": [
            {
              "depth": 1,
              "value": "这是前端开发比较有用的网站",
              "heading": "这是前端开发比较有用的网站"
            },
            {
              "depth": 2,
              "value": "提升开发速度好用",
              "heading": "提升开发速度好用"
            }
          ],
          "title": "这是前端开发比较有用的网站",
          "nav": {
            "path": "/zh-CN/guide",
            "title": "前端之路"
          },
          "group": {
            "path": "/zh-CN/guide/好用的网站",
            "title": "好用的网站"
          },
          "locale": "zh-CN"
        },
        "title": "这是前端开发比较有用的网站 - 知识海洋里的淡水鱼"
      },
      {
        "path": "/zh-CN/guide/我的type-script相关代码",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'docs__guide__我的TypeScript相关代码__index.md' */'F:/LYH_work/mycode/my-markdown/docs/guide/我的TypeScript相关代码/index.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "docs/guide/我的TypeScript相关代码/index.md",
          "updatedTime": 1663839587000,
          "title": "我的TypeScript相关代码",
          "order": 1,
          "nav": {
            "title": "前端之路",
            "order": 1,
            "path": "/zh-CN/guide"
          },
          "slugs": [
            {
              "depth": 1,
              "value": "我的 TypeScript 相关代码",
              "heading": "我的-typescript-相关代码"
            },
            {
              "depth": 2,
              "value": "enum",
              "heading": "enum"
            },
            {
              "depth": 2,
              "value": "infer",
              "heading": "infer"
            },
            {
              "depth": 2,
              "value": "索引访问类型",
              "heading": "索引访问类型"
            },
            {
              "depth": 2,
              "value": "映射类型",
              "heading": "映射类型"
            },
            {
              "depth": 2,
              "value": "模板字面量类型",
              "heading": "模板字面量类型"
            },
            {
              "depth": 2,
              "value": "内置字符操作类型",
              "heading": "内置字符操作类型"
            },
            {
              "depth": 2,
              "value": "Utility Types",
              "heading": "utility-types"
            },
            {
              "depth": 3,
              "value": "Awaited<Type>",
              "heading": "awaitedtype"
            },
            {
              "depth": 3,
              "value": "Partial<Type>",
              "heading": "partialtype"
            },
            {
              "depth": 3,
              "value": "Required<Type>",
              "heading": "requiredtype"
            },
            {
              "depth": 3,
              "value": "Readonly<Type>",
              "heading": "readonlytype"
            },
            {
              "depth": 3,
              "value": "Record<Keys, Type>",
              "heading": "recordkeys-type"
            },
            {
              "depth": 3,
              "value": "Pick<Type, Keys>",
              "heading": "picktype-keys"
            },
            {
              "depth": 3,
              "value": "Omit<Type, Keys>",
              "heading": "omittype-keys"
            },
            {
              "depth": 3,
              "value": "Exclude<UnionType, ExcludedMembers>",
              "heading": "excludeuniontype-excludedmembers"
            },
            {
              "depth": 3,
              "value": "Extract<Type, Union>",
              "heading": "extracttype-union"
            },
            {
              "depth": 3,
              "value": "NonNullable<Type>",
              "heading": "nonnullabletype"
            },
            {
              "depth": 3,
              "value": "Parameters<Type>",
              "heading": "parameterstype"
            },
            {
              "depth": 3,
              "value": "ConstructorParameters<Type>",
              "heading": "constructorparameterstype"
            },
            {
              "depth": 3,
              "value": "ReturnType<Type>",
              "heading": "returntypetype"
            },
            {
              "depth": 3,
              "value": "InstanceType<Type>",
              "heading": "instancetypetype"
            },
            {
              "depth": 3,
              "value": "ThisParameterType<Type>",
              "heading": "thisparametertypetype"
            },
            {
              "depth": 3,
              "value": "OmitThisParameter<Type>",
              "heading": "omitthisparametertype"
            },
            {
              "depth": 3,
              "value": "ThisType<Type>",
              "heading": "thistypetype"
            },
            {
              "depth": 2,
              "value": "我的工具函数",
              "heading": "我的工具函数"
            },
            {
              "depth": 3,
              "value": "OverrideProperty",
              "heading": "overrideproperty"
            },
            {
              "depth": 3,
              "value": "DeepPartial",
              "heading": "deeppartial"
            },
            {
              "depth": 3,
              "value": "DeepRequired",
              "heading": "deeprequired"
            },
            {
              "depth": 3,
              "value": "GetCommonKeys",
              "heading": "getcommonkeys"
            },
            {
              "depth": 3,
              "value": "DeletePartial",
              "heading": "deletepartial"
            },
            {
              "depth": 3,
              "value": "差集",
              "heading": "差集"
            },
            {
              "depth": 3,
              "value": "tuple => union",
              "heading": "tuple--union"
            },
            {
              "depth": 3,
              "value": "union => intersection",
              "heading": "union--intersection"
            },
            {
              "depth": 2,
              "value": "操作符",
              "heading": "操作符"
            },
            {
              "depth": 2,
              "value": "type 与 interface 的区别",
              "heading": "type-与-interface-的区别"
            },
            {
              "depth": 2,
              "value": "提取函数类型",
              "heading": "提取函数类型"
            },
            {
              "depth": 2,
              "value": "dispath 转换",
              "heading": "dispath-转换"
            },
            {
              "depth": 2,
              "value": "混合继承",
              "heading": "混合继承"
            },
            {
              "depth": 2,
              "value": "React 与 TypeScript",
              "heading": "react-与-typescript"
            },
            {
              "depth": 3,
              "value": "TypeScript 获取 react 及 vue 组件实例",
              "heading": "typescript-获取-react-及-vue-组件实例"
            },
            {
              "depth": 4,
              "value": "class 获取组件实例",
              "heading": "class-获取组件实例"
            },
            {
              "depth": 4,
              "value": "hook 获取 ref - 1",
              "heading": "hook-获取-ref---1"
            },
            {
              "depth": 4,
              "value": "hook 获取 ref - 2",
              "heading": "hook-获取-ref---2"
            },
            {
              "depth": 4,
              "value": "vue3",
              "heading": "vue3"
            },
            {
              "depth": 2,
              "value": "报错的解决",
              "heading": "报错的解决"
            },
            {
              "depth": 3,
              "value": "元组",
              "heading": "元组"
            },
            {
              "depth": 3,
              "value": "对象索引形式",
              "heading": "对象索引形式"
            },
            {
              "depth": 3,
              "value": "对象尚未定义",
              "heading": "对象尚未定义"
            }
          ],
          "group": {
            "path": "/zh-CN/guide/我的type-script相关代码",
            "title": "我的TypeScript相关代码"
          },
          "locale": "zh-CN"
        },
        "title": "我的TypeScript相关代码 - 知识海洋里的淡水鱼"
      },
      {
        "path": "/zh-CN/guide/未整理",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'docs__guide__未整理__index.md' */'F:/LYH_work/mycode/my-markdown/docs/guide/未整理/index.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "docs/guide/未整理/index.md",
          "updatedTime": 1663839587000,
          "title": "未整理",
          "order": 1,
          "nav": {
            "title": "前端之路",
            "order": 1,
            "path": "/zh-CN/guide"
          },
          "slugs": [
            {
              "depth": 1,
              "value": "未整理",
              "heading": "未整理"
            },
            {
              "depth": 2,
              "value": "React",
              "heading": "react"
            },
            {
              "depth": 2,
              "value": "Vue",
              "heading": "vue"
            },
            {
              "depth": 2,
              "value": "js",
              "heading": "js"
            },
            {
              "depth": 2,
              "value": "gis",
              "heading": "gis"
            },
            {
              "depth": 3,
              "value": "地图遇到数据不显示时",
              "heading": "地图遇到数据不显示时"
            },
            {
              "depth": 2,
              "value": "其他",
              "heading": "其他"
            },
            {
              "depth": 2,
              "value": "可视化入门",
              "heading": "可视化入门"
            },
            {
              "depth": 3,
              "value": "canvas 教程",
              "heading": "canvas-教程"
            },
            {
              "depth": 3,
              "value": "svg 教程",
              "heading": "svg-教程"
            },
            {
              "depth": 3,
              "value": "d3 教程",
              "heading": "d3-教程"
            },
            {
              "depth": 3,
              "value": "webGL",
              "heading": "webgl"
            },
            {
              "depth": 3,
              "value": "threejs",
              "heading": "threejs"
            },
            {
              "depth": 3,
              "value": "工具",
              "heading": "工具"
            },
            {
              "depth": 3,
              "value": "其他链接",
              "heading": "其他链接"
            }
          ],
          "group": {
            "path": "/zh-CN/guide/未整理",
            "title": "未整理"
          },
          "locale": "zh-CN"
        },
        "title": "未整理 - 知识海洋里的淡水鱼"
      },
      {
        "path": "/zh-CN/guide/高级前端必读",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'docs__guide__高级前端必读__index.md' */'F:/LYH_work/mycode/my-markdown/docs/guide/高级前端必读/index.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "docs/guide/高级前端必读/index.md",
          "updatedTime": 1663839587000,
          "title": "高级前端必读",
          "order": 1,
          "nav": {
            "title": "前端之路",
            "order": 1,
            "path": "/zh-CN/guide"
          },
          "slugs": [
            {
              "depth": 2,
              "value": "高级前端必读",
              "heading": "高级前端必读"
            }
          ],
          "group": {
            "path": "/zh-CN/guide/高级前端必读",
            "title": "高级前端必读"
          },
          "locale": "zh-CN"
        },
        "title": "高级前端必读 - 知识海洋里的淡水鱼"
      },
      {
        "path": "/zh-CN/map",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'docs__map__index.md' */'F:/LYH_work/mycode/my-markdown/docs/map/index.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "docs/map/index.md",
          "updatedTime": 1668592556000,
          "title": "总览",
          "nav": {
            "path": "/zh-CN/map",
            "title": "地图",
            "order": 2
          },
          "slugs": [
            {
              "depth": 1,
              "value": "gis",
              "heading": "gis"
            },
            {
              "depth": 1,
              "value": "常用的前端地图框架（WebGIS 框架）",
              "heading": "常用的前端地图框架webgis-框架"
            },
            {
              "depth": 3,
              "value": "Leaflet",
              "heading": "leaflet"
            },
            {
              "depth": 3,
              "value": "Mapbox GL JS",
              "heading": "mapbox-gl-js"
            },
            {
              "depth": 3,
              "value": "ArcGIS API for JS",
              "heading": "arcgis-api-for-js"
            },
            {
              "depth": 3,
              "value": "Openlayers",
              "heading": "openlayers"
            },
            {
              "depth": 3,
              "value": "Cesium",
              "heading": "cesium"
            },
            {
              "depth": 3,
              "value": "百度地图 JS API /百度地图 API GL",
              "heading": "百度地图-js-api-百度地图-api-gl"
            },
            {
              "depth": 3,
              "value": "高德地图 JS API",
              "heading": "高德地图-js-api"
            },
            {
              "depth": 3,
              "value": "Google Maps JS API",
              "heading": "google-maps-js-api"
            },
            {
              "depth": 3,
              "value": "AntV L7",
              "heading": "antv-l7"
            },
            {
              "depth": 1,
              "value": "在线地图服务的 url",
              "heading": "在线地图服务的-url"
            },
            {
              "depth": 2,
              "value": "　　上面的、、 这些表示该区间内的数值，任取一个即可。（在 openlayers 里面加载直接这样写可以，在 QGIS 里需要取一个值）",
              "heading": "上面的-这些表示该区间内的数值任取一个即可在-openlayers-里面加载直接这样写可以在-qgis-里需要取一个值"
            }
          ],
          "locale": "zh-CN"
        },
        "title": "总览 - 知识海洋里的淡水鱼"
      },
      {
        "path": "/zh-CN/map/leaflet",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'docs__map__Leaflet__index.md' */'F:/LYH_work/mycode/my-markdown/docs/map/Leaflet/index.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "docs/map/Leaflet/index.md",
          "updatedTime": 1668592556000,
          "slugs": [
            {
              "depth": 1,
              "value": "快速开始",
              "heading": "快速开始"
            },
            {
              "depth": 3,
              "value": "初始化一个带有图层的地图",
              "heading": "初始化一个带有图层的地图"
            }
          ],
          "title": "快速开始",
          "hasPreviewer": true,
          "nav": {
            "path": "/zh-CN/map",
            "title": "地图"
          },
          "group": {
            "path": "/zh-CN/map/leaflet",
            "title": "Leaflet"
          },
          "locale": "zh-CN"
        },
        "title": "快速开始 - 知识海洋里的淡水鱼"
      },
      {
        "path": "/zh-CN/mapbox",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'docs__map__Mapbox__index.md' */'F:/LYH_work/mycode/my-markdown/docs/map/Mapbox/index.md'), loading: LoadingComponent}),
        "exact": true,
        "meta": {
          "filePath": "docs/map/Mapbox/index.md",
          "updatedTime": 1668592556000,
          "slugs": [
            {
              "depth": 1,
              "value": "Mapbox",
              "heading": "mapbox"
            },
            {
              "depth": 1,
              "value": "分屏展示 Demo",
              "heading": "分屏展示-demo"
            }
          ],
          "title": "Mapbox",
          "hasPreviewer": true,
          "nav": {
            "path": "/zh-CN/map",
            "title": "地图"
          },
          "group": {
            "path": "/zh-CN/mapbox",
            "title": "Mapbox"
          },
          "locale": "zh-CN"
        },
        "title": "Mapbox - 知识海洋里的淡水鱼"
      },
      {
        "path": "/components/AutoScrollList",
        "meta": {},
        "exact": true,
        "redirect": "/components/AutoScrollList/auto-scroll-list"
      },
      {
        "path": "/components",
        "meta": {},
        "exact": true,
        "redirect": "/components/AutoScrollList"
      },
      {
        "path": "/components/EditTableHeader",
        "meta": {},
        "exact": true,
        "redirect": "/components/EditTableHeader/edit-table-header"
      },
      {
        "path": "/zh-CN/components/EditTableHeader",
        "meta": {},
        "exact": true,
        "redirect": "/zh-CN/components/EditTableHeader/edit-table-header"
      },
      {
        "path": "/zh-CN/components",
        "meta": {},
        "exact": true,
        "redirect": "/zh-CN/components/AutoScrollList"
      },
      {
        "path": "/components/Test",
        "meta": {},
        "exact": true,
        "redirect": "/components/Test/test"
      },
      {
        "path": "/zh-CN/components/Test",
        "meta": {},
        "exact": true,
        "redirect": "/zh-CN/components/Test/test"
      },
      {
        "path": "/guide/基础知识js",
        "meta": {},
        "exact": true,
        "redirect": "/guide/基础知识js/内置对象"
      },
      {
        "path": "/guide/好用的网站",
        "meta": {},
        "exact": true,
        "redirect": "/guide/好用的网站/好用的网站"
      },
      {
        "path": "/zh-CN/components/AutoScrollList",
        "meta": {},
        "exact": true,
        "redirect": "/zh-CN/components/AutoScrollList/auto-scroll-list"
      },
      {
        "path": "/zh-CN/guide/基础知识js",
        "meta": {},
        "exact": true,
        "redirect": "/zh-CN/guide/基础知识js/内置对象"
      },
      {
        "path": "/zh-CN/guide/好用的网站",
        "meta": {},
        "exact": true,
        "redirect": "/zh-CN/guide/好用的网站/好用的网站"
      }
    ],
    "title": "知识海洋里的淡水鱼",
    "component": (props) => props.children
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
